<?php
require_once('../db_connection.php');


$missing_data = array();


if(empty($_POST['id'])){
    $missing_data[] = 'id';
}
else{
    $id = trim($_POST['id']);
    $id = htmlspecialchars(addslashes($id));
}

if(empty($_POST['question'])){
     $missing_data[] = 'question';
}
else {
    $question = htmlspecialchars(addslashes(ucfirst($_POST['question'])));
 }

if(empty($_POST['question_points'])){
    $missing_data[] = 'question_points';
}
else{
    $question_points = trim($_POST['question_points']);
    $question_points = htmlspecialchars(addslashes(ucfirst($question_points)));
}

if(empty($_POST['choice1'])){
    $missing_data[] = 'choice1';
}
else{
    $choice1= trim($_POST['choice1']);
    $choice1 = htmlspecialchars(addslashes(ucfirst($choice1)));
}

if(empty($_POST['choice2'])){
    $missing_data[] = 'choice2';
}
else{
    $choice2= trim($_POST['choice2']);
    $choice2 = htmlspecialchars(addslashes(ucfirst($choice2)));
}

if(empty($_POST['choice3'])){
    $missing_data[] = 'choice3';
}
else{
    $choice3= trim($_POST['choice3']);
    $choice3 = htmlspecialchars(addslashes(ucfirst($choice3)));
}

if(empty($_POST['choice4'])){
    $missing_data[] = 'choice4';
}
else{
    $choice4= trim($_POST['choice4']);
    $choice4 = htmlspecialchars(addslashes(ucfirst($choice4)));
}

if(empty($_POST['correct_choice'])){
    $missing_data[] = 'correct_choice';
}
else{
    $correct_choice= trim($_POST['correct_choice']);
    $correct_choice = htmlspecialchars(addslashes($correct_choice));
}

    if(empty($missing_data)){
        // print_r($steps);


        $query1 = "INSERT INTO questions (article_id, question, choice1, choice2, choice3, choice4, points,correct_choice)
                            VALUES (?,?,?,?,?,?,?,?)";

        $statement1 = mysqli_prepare($connection,$query1);
        mysqli_stmt_bind_param($statement1,"issssssi", $id,$question,
            $choice1,$choice2,$choice3,$choice4,$question_points,$correct_choice);

        mysqli_stmt_execute($statement1);
        $rows_changed1 = mysqli_stmt_affected_rows($statement1);

        $id = mysqli_insert_id($connection);




        if(($rows_changed1>0)){

            echo "\nQuestion added succesfully\n";


            mysqli_stmt_close($statement1);
            // mysqli_stmt_close($statement2);
            mysqli_close($connection);


        }

        else{

            echo "\nThere was an error adding the question. Please recheck the form and try again.\n";
            echo mysqli_error($connection);
            // echo "\nrows1: ". $rows_changed1;
            // echo "\nrows2: ". $rows_changed2;
            // if(($rows_changed1>0)&&($rows_changed2<1)){
            //   $query_delete = "DELETE FROM recipe WHERE id = {$id}";
            //   $response= @mysqli_query($connection,$query_delete);
            // }

            mysqli_stmt_close($statement1);
            // mysqli_stmt_close($statement2);
            mysqli_close($connection);
        }


    }

    else{

        echo "\nError. Please make sure that you have entered the following field(s) and resubmit the form:";
        // print_r($missing_data);

        foreach ($missing_data as $key => $value) {
          echo "\n{$value} (required)";

        }
    }


?>
