<!DOCTYPE html>
<?php

//include('updateAll.php');

require_once('../db_connection.php');

$article_id = isset($_GET['article_id']) ? $_GET['article_id'] : '';

$query = "SELECT * FROM articles where id=".$article_id;
$response = @mysqli_query($connection,$query);
$row = mysqli_fetch_assoc($response);
$topic=$row["topic"];
$category=$row["category"];
$length=$row["length"];
$title=$row["name"];
?>

<html lang="en">
  <head>
    <style>
    .error {color: #FF0000;}
    </style>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Update Article</title>
	<!-- favicon -->

	<!-- link to google font -->
	<link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">



  </head>
  <body>
   &nbsp  <a  href=modifyArticle.php>Back</a>
    <br>
    <h1> Update Article</h1>

    <p><span class="error">* required field</span></p>

	<div class="container">

	<div class="container_search">
		<div class="row">
		<div class="col-md-12 container_search">


	<div class="container", id= "mainDiv">
	<form action="" method="post" id="form" enctype="multipart/form-data">




	<br>
    <p> <span class="error">*</span>  Article Title: <input type ="text" required name="title" id ="tile" size="180" value="<?php echo $title?>" /> </p>

    <p>   &nbsp  Topic <select name="topic"  id ="topic">
        <option <?php if($topic == 'Technology'){echo("selected");}?>>Technology</option>
        <option <?php if($topic == 'Education'){echo("selected");}?>>Education</option>
        <option <?php if($topic == 'Health & Nutrition'){echo("selected");}?>>Health & Nutrition</option>

    </select></p>

    <p>  &nbsp Category <select name="category" id ="category">
        <option <?php if($category == 'News'){echo("selected");}?>>News</option>
        <option <?php if($category == 'Advice'){echo("selected");}?>>Advice</option>
        <option <?php if($category == 'Analysis'){echo("selected");}?>>Analysis</option>
        <option <?php if($category == 'Interview'){echo("selected");}?>>Interview</option>
        <option <?php if($category == 'Discussion'){echo("selected");}?>>Discussion</option>
    </select></p>

    <p>  &nbsp Length <select name="length" id ="length">
        <option <?php if($length == 'Short'){echo("selected");}?>>Short</option>
        <option <?php if($length == 'Medium'){echo("selected");}?>>Medium</option>
        <option <?php if($length == 'Long'){echo("selected");}?>>Long</option>

    </select></p>

  <p>  &nbsp Tags (optional): <input type ="text" name="tags" id ="tags" value="<?php echo $row["tags"]?>" /></p>
	<p> <span class="error">*</span> Reading Time (Minutes): <input type ="text" required name="time" id ="time" size="10" value="<?php echo $row["reading_time"]?>" />  </p>
	<p>  Article overview (optional): <input type ="text" name="overview" id ="overview"  size="18'" value="<?php echo $row["overview"]?>" /></p>
  <p> <span class="error">*</span> Article Link (URL): <input type ="text" required name="link" id ="link" size="170" value="<?php echo $row["link"]?>" />  </p>



  </select></p>
    </div>

    <p>&nbsp &nbsp &nbsp <input type ="submit" name="update" id= "button" class="submit_btn" value="Update" >  &nbsp  &nbsp

</form>
<?php

if(isset($_POST['update']))
{ //Save values in variables
  $title = mysqli_real_escape_string($connection,$_POST['title']);
  $topic = mysqli_real_escape_string($connection,$_POST['topic']);
  $category = mysqli_real_escape_string($connection,$_POST['category']);
  $tags = mysqli_real_escape_string($connection,$_POST['tags']);
  $time = mysqli_real_escape_string($connection,$_POST['time']);
  $overview = mysqli_real_escape_string($connection,$_POST['overview']);
  $link = mysqli_real_escape_string($connection,$_POST['link']);
  $length = mysqli_real_escape_string($connection,$_POST['length']);

  $sqlquery = "UPDATE articles SET name='$title', topic='$topic', category='$category', length='$length',tags='$tags',overview='$overview',link='$link', reading_time=$time WHERE id=$article_id";


  if (mysqli_query($connection, $sqlquery)) {
    echo '<script language="javascript">';
    echo 'alert("Record updated successfully")';

    echo '</script>';


  } else {
    echo '<script language="javascript">';
    $message="Error updating record: " . mysqli_error($connection);
    echo 'alert("' . $message . '")';
    echo '</script>';
}


}

?>

</body>

</html>
