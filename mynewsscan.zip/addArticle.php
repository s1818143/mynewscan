<?php
require_once('../db_connection.php');


// echo "\n";
// print_r($_POST);
// echo "\n";


$missing_data = array();
$steps = array();

if(empty($_POST['name'])){
    $missing_data[] = 'name';
}
else{
    $name = trim($_POST['name']);
    $name = htmlspecialchars(addslashes(ucfirst($name)));
}

if(empty($_POST['topic'])){
     $missing_data[] = 'topic';
}
else {
    $topic = ucfirst($_POST['topic']);
 }

if(empty($_POST['category'])){
    $missing_data[] = 'category';
}
else {
    $category = ucfirst($_POST['category']);
}

if(empty($_POST['length'])){
    $missing_data[] = 'length';
}
else {
    $length = ucfirst($_POST['length']);
}

if(empty($_POST['tags'])){
    $tags="";
}
else{
    $tags = trim($_POST['tags']);
    $tags = htmlspecialchars(addslashes(ucfirst($tags)));
}

if(empty($_POST['time'])){
    $missing_data[] = 'Time';
}
else{
    $time= trim($_POST['time']);
    $time = htmlspecialchars(addslashes(ucfirst($time)));
}

if(!empty($_POST['overview'])){
//     $missing_data[] = 'Overview';
// }
// else{
    $overview= trim($_POST['overview']);
    $overview = htmlspecialchars(addslashes(ucfirst($overview)));
}

if(empty($_POST['link'])){
    $missing_data[] = 'link';
}
else{

    $link = htmlspecialchars(mysqli_real_escape_string($connection,$_POST['link']));
    $url = $_POST['link'];
    $id=uniqID();
    $file = "articles/article".$id.".html";



    $ch = curl_init($url);
    $fp = fopen($file, "w");

    curl_setopt($ch, CURLOPT_FILE, $fp);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch,CURLOPT_FOLLOWLOCATION,true);
    curl_exec($ch);
    curl_close($ch);
    fclose($fp);



}
// echo "\n";
// echo $r_name;
// echo "\n";
// echo $category;
// echo "\n";
// echo $cuisine;
// echo "\n";
// echo $ingredients;
// echo "\n";
// echo $time;
// echo "\n";
// echo $serves;
// echo "\n";
$imageID= uniqid();
// echo "\n$imageID\n";
if(!empty($_FILES['image'])){
    // // echo "\n Warning image one not found";
    // $missing_data[]='Image';

// }
// else {
//   // echo"image one found";
$image_one="Images/";
$image_one =addslashes($image_one.$imageID.basename($_FILES['image']['name']));
$imageID=uniqid();
move_uploaded_file($_FILES['image']['tmp_name'],$image_one);
}


// for($i=1;$i<51;$i++){
//   $step = "step".$i;
//   if(isset($_POST[$step])){
//     if(empty($_POST[$step])){
//       $missing_data[] = "{$step}";
//     }
//     else{
//       $steps[]= htmlspecialchars(addslashes(ucfirst(trim($_POST[$step]))));
//
//     }
//
//   }
//
// }



    if(empty($missing_data)){
        // print_r($steps);


        $query1 = "INSERT INTO articles (name, time_added, topic, category, length, tags, overview, link, image_path, reading_time, article_path)
                            VALUES (?,NOW(),?,?,?,?,?,?,?,?,?)";

        $statement1 = mysqli_prepare($connection,$query1);
        mysqli_stmt_bind_param($statement1,"ssssssssss", $name,$topic,
            $category,$length,$tags,$overview,$link,
            $image_one,$time,$file);

        mysqli_stmt_execute($statement1);
        $rows_changed1 = mysqli_stmt_affected_rows($statement1);

        $id = mysqli_insert_id($connection);
        // echo "\n id is: ";
        // echo $id;
        //

        // $query2 = "INSERT INTO steps (step, id) VALUES (?, ?)";
        //
        // // $rows_changed = mysqli_stmt_affected_rows($statement);
        //
        // $statement2 = mysqli_prepare($connection,$query2);
        //
        // // print_r($steps);
        //
        //
        //
        //
        // foreach ($steps as $key => $value) {
        //     // echo "\nid is {$id}";
        //     // echo "\n{$key} => {$value} ";
        //
        //     if(!empty($value)){
        //     mysqli_stmt_bind_param($statement2,"si", $value,
        //         $id);
        //
        //     mysqli_stmt_execute($statement2);
        //     $rows_changed2= mysqli_stmt_affected_rows($statement2);
        //     // echo "\nrow2 is now".  $rows_changed2;
        //     if($rows_changed2<1){
        //       break;
        //
        //     }
        //   }
        //
        // }



        if(($rows_changed1>0)){

            echo "\nArticle added succesfully\n";


            mysqli_stmt_close($statement1);
            // mysqli_stmt_close($statement2);
            mysqli_close($connection);


        }

        else{

            echo "\nThere was an error adding the article. Please recheck the form and try again.\n";
            echo mysqli_error($connection);
            // echo "\nrows1: ". $rows_changed1;
            // echo "\nrows2: ". $rows_changed2;
            // if(($rows_changed1>0)&&($rows_changed2<1)){
            //   $query_delete = "DELETE FROM recipe WHERE id = {$id}";
            //   $response= @mysqli_query($connection,$query_delete);
            // }

            mysqli_stmt_close($statement1);
            // mysqli_stmt_close($statement2);
            mysqli_close($connection);
        }


    }

    else{

        echo "\nError. Please make sure that you have entered the following field(s) and resubmit the form:";
        // print_r($missing_data);

        foreach ($missing_data as $key => $value) {
          echo "\n{$value} (required)";

        }
    }


?>
