<?php include('server.php') ?>

<!DOCTYPE html>

<html>

	<head>
		<title>Login</title>
		<link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
		<link rel="stylesheet" href="assets/css/Navigation-with-Button.css">
		<link rel="stylesheet" href="assets/css/styles.css">
		<link rel="stylesheet" type="text/css" href="assets/css/login.css">
	</head>

	<body>

		<div id="nav">
	    <nav class="navbar navbar-light navbar-expand-md fixed-top navigation-clean-button has-pattern">
	      <div class="container-fluid">
	        <h1 class="logo pull-left">
	          <a class="navbar-brand" href="schema.php">
	            <!--<img id="logo-image" class="logo-image" src="img/logo.png" alt="Logo">-->
	            <span>Meta News Platform</span>
	          </a>
	        </h1>

	</div>
	    </nav>
	  </div>
<br>

<br>

	<div class="wrap">
		<h1>Login</h1>
		<form action="login.php" method="post" name="userform">
			<!--For error messages -->
			<?php if (count($errors)> 0): ?>
				<div class="error">
					<?php foreach ($errors as $error): ?>
						<p><?php echo $error; ?> </p>
					<?php endforeach ?>
				</div>
			<?php endif ?>


			<label>Username</label>
			<input type="text" name="username" autocomplete="off">
			<label>Password</label>
			<input type="password" name="password"  autocomplete="off">


			<input type="submit" value="Login" name="login">

			<p>Not registered? <a href=register.php>Sign up</a>
			</p>

			 <a href=forgotPass.html>Forgot your password? </a>


		</form>

	</div>
	</body>
</html>
