<?php
require_once('../db_connection.php');


if(empty($_POST['user_id'])){
    $missing_data[] = 'user_id';
}
else{
    $user_id = trim($_POST['user_id']);
    $user_id = htmlspecialchars(addslashes($user_id));
}

if(empty($_POST['article_id'])){
    $missing_data[] = 'article_id';
}
else{
    $article_id = trim($_POST['article_id']);
    $article_id = htmlspecialchars(addslashes($article_id));
}


    $points= $_POST['points'];
    $points = htmlspecialchars(addslashes($points));


if($user_id!=-1){
$query = "SELECT * FROM users WHERE user_id = {$user_id} ";
$response= @mysqli_query($connection,$query);
$checkQuery1 = mysqli_query($connection,"SELECT * FROM recentAnswers WHERE user_id = {$user_id} AND article_id= {$article_id}");
$checkQuery2 = mysqli_query($connection,"SELECT * FROM answers WHERE user_id = {$user_id} AND article_id= {$article_id}");

if(mysqli_num_rows($checkQuery1) == mysqli_num_rows($checkQuery2)){
if($response){
  $row = mysqli_fetch_array($response);
  $existingPoints = $row['total_points'];
  $newpoints = $existingPoints + $points;


  $pointsQuery = "UPDATE users SET total_points = {$newpoints} WHERE user_id = {$user_id}";
  if(mysqli_query($connection, $pointsQuery))
      echo $_POST['points'] . " points added successfully";

}

}

}


else{

    echo "\nThere was an error adding the points. Please recheck the form and try again.\n";
    echo mysqli_error($connection);

    mysqli_close($connection);
}











?>
