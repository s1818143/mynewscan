<?php
require_once('../db_connection.php');
$query = "SELECT * FROM articles";
$response = @mysqli_query($connection,$query);

?>


<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ModifyArticle</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<div class="topnav">
      <a class="active" href="add_article.html">Add Articles</a>
      <a class="active" href="question_form.php">Add Questions</a>
      <a href="modifyArticle.php">Modify Articles & Questions</a>
      <a href="exploration.php">View Exploration</a>
      <a href="answers.php">View Answers</a>
      <a href="statistics.php">Statistics</a>

</div>
<body>
    <div class="container" id="con">
        <h1>Remove or Modify an Article</h1>
        <h4>Please select an article from the database and the desired option.</h4>
        <div>
          <form id="form"  method="post">

            <p>Select an article: <select name="article" id="article" onchange="getSource(this.id)" ></select></p>
            <p> <a href="" id="source"> </a></p>
            </form>

             <!--<p>Select number of questions to add for this article: <select name="questions" id="question" onchange="makeQuestions(this.id)" ></select></p>

            <!-- <div>
                <p>Question 1:</p><label>Question: &nbsp; &nbsp;</label><input type="text">
                <p></p><label>Answer choice 1:&nbsp;</label><input type="text">
                <p></p><label>Answer choice 2:&nbsp;</label><input type="text">
                <p></p><label>Answer choice 3:&nbsp;</label><input type="text">
                <p></p><label>Answer choice 4:&nbsp;</label><input type="text"></div>
        </div> -->
    </div>
  </div>

    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <div class="container">
    <p> <input type ="submit" name="delete"  class="submit_btn" value="Delete Article" onclick="deleteArticle()"  />

  &nbsp &nbsp  <input type ="submit" name="modify"  class="submit_btn" value="Modify Article" onclick="modifyArticle()"/>

&nbsp &nbsp    <input type ="submit" name="modifyq"  class="submit_btn" value="Modify Questions" onclick="modifyQuestions()"/>

  </div>
</body>
<script>
<?php
if($response) { ?>
  var ids= {};
  var links = {};
  var question ={};
  var questionList = [];
  var article_id;

function getArticles(id){

  var articles = document.getElementById("article");
  <?php

   $i=0;
  while($row = mysqli_fetch_array($response)){ ?>
  var option = document.createElement("OPTION");
  field = document.createTextNode("<?php echo stripslashes($row['name']);?>");
  option.appendChild(field);
  articles.insertBefore(option,articles.lastChild);
  links["<?php echo stripslashes($row['name']);?>"] = "<?php echo $row['link'];?>";
  ids["<?php echo stripslashes($row['name']);?>"] = "<?php echo $row['id'];?>";
  <?php } ?>

}


  function getSource(id){

    var source = document.getElementById("source");
    var key = document.getElementById("article").value;
    console.log(key);
    console.log(links[key]);
    source.setAttribute("href", links[key] );
    source.innerHTML= links[key];
    article_id = ids[key];
  }



  getArticles("article");
  getSource("article");


  <?php

}

else{
  echo  "Could not issue DB query";
  echo mysqli_errno($connection);
}

?>

function deleteArticle(){
  var articleName;

  articleName = document.getElementById("article").value;
window.location = "modifyArticle.php?article_id=" + article_id;

    <?php
    $article_id = isset($_GET['article_id']) ? $_GET['article_id'] : '';

    $query = "DELETE FROM articles WHERE id=$article_id";
    if(mysqli_query($connection,$query))
    $x =1;
    else {
      $x=0;
    }
    //echo "delete";
     ?>
   alert ("article deleted");


}

function modifyArticle(){
  window.location = "updateArticle.php?article_id=" + article_id;
}

function modifyQuestions(){
  window.location = "updateQuestions.php?article_id=" + article_id;
}

</script>


</html>
