<html>
<?php
require_once('../db_connection.php');
session_start();
$query = "SELECT * FROM articles ORDER BY RAND()";
$response= @mysqli_query($connection,$query);


$logged=0;
$caption="Log In";
$logging_link="login.php";
$button ="Sign Up";
$button_link ="register.php";
$user_status=-1;
$userID=-1;

if(isset($_SESSION['logged'])){
  if($_SESSION['logged'])
    $logged=1;
}

if($logged==1){
$userID= $_SESSION['user_id'];
$login_details = "SELECT * FROM users where user_id={$userID}";
$login_response= @mysqli_query($connection,$login_details);

if($login_response){
 $user_record = mysqli_fetch_array($login_response);
 $user_status = $user_record['status'];
 $username = $user_record['username'];
 $email = $user_record['email'];
 if($user_status){
   $caption = "Log Out";
   $logging_link ="login.php";
   $button ="{$username}";
   $button_link ="profile.php";
 }

}


else{

echo "no response ".mysqli_errno($connection);
}

}
?>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Meta News Platform</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css">
		<link rel="stylesheet" href="assets/fonts/material-icons.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Cookie">
    <link rel="stylesheet" href="assets/css/Footer-Basic.css">
    <link rel="stylesheet" href="assets/css/Footer-Dark.css">
    <link rel="stylesheet" href="assets/css/Navigation-with-Button.css">
    <link rel="stylesheet" href="assets/css/Pretty-Footer.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/untitled.css">
    <link rel="stylesheet" href="assets/css/profile.css">
</head>

<body>
<!--[if IE 7]>
<style>
		.bing {
				background-color: #fa7a20;
				paddind-left: 248px;
				margin-top: 7px;
		}
</style>
<![endif]-->
<!--[if lt IE 7]>
<![endif]-->
<!--[if gte IE 7]>
<![endif]-->
<!--[if IE 8]>
<style>
		.bing {
				background-color: #fa7a20;
				margin-top: -44px;
				paddind-left: 248px;
		}
</style>
<![endif]-->
<div id="nav">
	<nav class="navbar navbar-light navbar-expand-md fixed-top navigation-clean-button has-pattern">
		<div class="container-fluid">
			<h1 class="logo pull-left">
				<a class="navbar-brand" href="schema.php">
					<!--<img id="logo-image" class="logo-image" src="img/logo.png" alt="Logo">-->
					<span>Meta News Platform</span>
				</a>
			</h1>
			<button class="navbar-toggler" data-toggle="collapse" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
				<div class="collapse navbar-collapse" id="navcol-1">
						<ul class="nav navbar-nav ml-auto">
							<li class="nav-item dropdown" role="presentation"><a class="nav-link" href="#" id="aboutUs">About Us</a>
								<div class="dropdown-content">
									<a href="#">Reward System</a>
									<a href="#">Contact Us</a>
									<a href="#">About Us</a>
								</div></li>
								<!--<li class="nav-item" role="presentation"><a class="nav-link" href="#" id="contact">Contact</a></li>-->
						</ul><span class="navbar-text actions"> <a href="<?php echo $logging_link;?>" id="login" class="login"><?php echo $caption;?> </a> <a class="btn btn-light action-button" id="loginButton" role="button" href="<?php echo $button_link;?>"><?php echo $button;?>
						</a></span></div>
</div>
	</nav>
</div>

<div class="g-bd2 g-bd2-1">
	<div class="g-mn">
		<div class="g-mnc">
			<div class="accountsetting">
				<div class="u-ttl">
					<h3>Account Setting</h3>
				</div>
				<div class="container">
					<div class="u-colslist">
<div class="suc_content">
<div class="suc_kuang nojsp">
<div class="hei_513">
	<p class="info">
		<span class="detailtitle">Username:</span> <span class="detailcontent"><?php echo $username ; ?></span>
	<p>
		<span class="detailtitle">Email:</span> <span class="detailcontent"><?php echo $email; ?></span>
	</p>
	<p>
<!-- 	<div class="detail">
		<div class="user_info clearfix">
			<dl style="display: block;" class="clearfix">
			<dt class="dt_l">Reset Password:</dt>
			<dd class="dd_r">
				<span class="userInfo"> <a
					id="showEditPasswordButton" href="javascript:void(0);">Reset</a>
					<a id="quitEditPwd" class="editBtn"
					href="javascript:void(0);" style="display:none;">Cancel</a>
				</span>
			</dd>
			<span id="editPwd" style="display:none;">
				<dt class="dt_l">Original Password:</dt>
				<dd class="dd_r clearfix" id="oldDD">
					<input class="input_kuang input_kuang_pwd" id="oldInput"
						type="password"> <span
						class="check_tips error_tip" id="tips_val">Password Incorrect</span>
				</dd>
				<dt class="dt_l">New Password:</dt>
				<dd class="dd_r clearfix" id="newDD">
					<input class="input_kuang input_kuang_pwd"
						name="repassword" id="newInput" type="password">
					<span class="check_tips error_tip" id="tips_val">Wrong format</span>
				</dd>
				<dt class="dt_l">Re-enter New Password:</dt>
				<dd class="dd_r clearfix" id="rNewDD">
					<input class="input_kuang input_kuang_pwd"
						name="repassword" id="rNewInput" type="password">
					<span class="check_tips error_tip" id="tips_val">Two input password must be consistent.</span>
				</dd>
				<dt class="dt_l">&nbsp;</dt>
				<dd class="dd_r la_height clearfix">
					<div class="sub_login flt_l">
						<button id="editPasswordBtn" class="no_bg">Confirm Reset</button>
					</div>
				</dd>
				</span>
			</dl>

		</div>
	</div> -->
</div>

</div>
</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div class="g-sd">
		<div class="nav-left">
			<h2>My Account</h2>
			<ul id="mod_sel">
				<li class="crt"><a href="profile.php" hidefocus="hidefocus">Account Setting</a></li>
				<li><a href="mypoints.php" hidefocus="hidefocus">My Points</a></li>
				<li><a href="recentreading.php" hidefocus="hidefocus">Recent Reading</a></li>
			</ul>
		</div>
	</div>
</div>




<div class="footer-basic">
	<footer>
		<div class="row">
			<div class="col-sm-6 col-md-4 footer-navigation">
				<h3></h3><img src="assets/img/neuro-header.jpg" id="edinburgh"><img src="assets/img/informatics_logo.jpg" id="informatics"></div>
				<div class="col-sm-6 col-md-4 footer-contacts">
					<div><span class="fa fa-map-marker footer-contacts-icon"> </span>
						<p id="address"><span class="new-line-span">1 George Square&nbsp;</span> Edinburgh, United Kingdom</p>
					</div>
					<div><i class="fa fa-phone footer-contacts-icon"></i>
						<p id="number" class="footer-center-info email text-left"><br>0131 650 3522 (Mon/Thurs)<br><br></p>
					</div>
					<div><i class="fa fa-envelope footer-contacts-icon"></i>
						<p id="email"> <a href="#" target="_blank"><br>edinburgh.neuroscience@ed.ac.uk<br><br></a></p>
					</div>
				</div>
				<div class="clearfix"></div>
				<div class="col-md-4 footer-about">
					<h4>About the company</h4>
					<p><br>Edinburgh Neuroscience is a vibrant, interdisciplinary, cross-College community at the University of Edinburgh whose ethos is collaborative and collegiate cooperation across all research areas. With over 500 fundamental and clinical
						researchers, based in 185 laboratories, our work spans the life course from prenatal to old age and attempts to answer the fundamental questionshow does the brain develop and function across the lifespanhow can it be protected
						and repaired?Our research takes place within a range of centres that work closely together, with clinical work being integrated across all areas. Edinburgh Neuroscience is widely recognised for its extensive integration of outstanding
						clinical, biomedical, informatics and psychology research.&nbsp;<br><br></p>
						<div class="social-links social-icons"><a href="#"><i class="fa fa-facebook"></i></a><a href="#"><i class="fa fa-twitter"></i></a><a href="#"><i class="fa fa-linkedin"></i></a><a href="#"><i class="fa fa-github"></i></a></div>
					</div>
				</div>
			</footer>
</div>

<script src="assets/js/jquery.min.js"></script>
<script src="assets/bootstrap/js/bootstrap.min.js"></script>
<script>//LOGOUT SCRIPT

var userID = <?php echo $userID;?>;
var logged = <?php echo $logged; ?>;
var status = <?php echo $user_status;?>;
var form = $('#login')[0]
var formData3 = new FormData(form);
formData3.append("status",status);
formData3.append("userID",userID);
// var logbutton = document.getElementById("login");

if(logged==1){
$( "#login" ).click(function( event ) {
   event.preventDefault();

    $.ajax({ url: 'logout.php',


              type: 'post',
              data: formData3,
              contentType: false, // NEEDED, DON'T OMIT THIS (requires jQuery 1.6+)
              processData: false,

         success: function(output) {
                      alert(output);
                      window.location.replace("<?php echo $logging_link;?>");

                  },
          error: function(request, error){
            alert("Error: Could not issue ajax request\n"+"Status: "+status+"\nuserID:"+userID+error+request);
          }
    });



  });
}
    </script>

    <script>

    function displayPoints(){

      <?php   if($logged==1){
        $userID= $_SESSION['user_id'];
        $login_details = "SELECT * FROM users where user_id={$userID}";
        $login_response= @mysqli_query($connection,$login_details);

        if($login_response){
          $user_record = mysqli_fetch_array($login_response);
          $points =$username." | Points:". $user_record['total_points'];
        }
      }
      else $points="Register to get points!";

      ?>
     return "<?php echo $points;?>";

    }
    var points = document.getElementById("loginButton");
    points.innerHTML=displayPoints();

    if(logged)
    points.setAttribute("href","mypoints.php");
    else {
     points.setAttribute("href","register.php");
    }

    </script>
</body>
</html>
