<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>ModifyArticle</title>
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
  <div class="topnav">
      <a class="active" href="add_article.html">Add Articles</a>
      <a class="active" href="question_form.php">Add Questions</a>
      <a href="modifyArticle.php">Modify Articles & Questions</a>
      <a href="exploration.php">View Exploration</a>
      <a href="answers.php">View Answers</a>
      <a href="statistics.php">Statistics</a>

  </div>

  <h1>Exploration</h1>
  <form action="" method="post">


    <p> order by <select onchange="=sort(this.id)" name="select" id ="order">
      <option value = "activity_id">activity ID</option>
      <option value = "time_added">Time Added</option>
      <option value = "article_id">Article ID</option>
      <option value = "user_id">User ID</option>
      <option value = "ip_address">IP Address</option>
      <option value = "country">Country</option>
    </select></p>
    <input name="Display" type="submit" value ="Click to display results"></input>
  </form>







  <?php


  if (isset($_POST['Display'])) {

    require_once('../db_connection.php');
    $orderby = $_POST['select'];
    $query = "SELECT * FROM activity ORDER BY {$orderby}";
    // echo "Query: ". $query;
    $response = @mysqli_query($connection,$query);

    $count =array();

    echo '<table align="center" border="1" style="{text-align: center;}">';
    //make the column headers what you want in whatever order you want
    echo '<tr><th>Activity ID</th><th>Activity</th><th>Time Added</th><th>Article ID</th><th>Article Name</th><th>User ID</th><th>User</th>
    <th>IP Address</th><th>Hostname</th><th>Country</th><th>Region</th><th>City</th><th>Coordinates</th><th>ISP Address</th></tr>';
    //loop the query data to the table in same order as the headers

    while ($row = mysqli_fetch_assoc($response)){
      echo "<tr><td>".$row['activity_id']."</td><td>".stripslashes($row['activity'])."</td><td>".$row['time_added']."</td><td>".$row['article_id']."</td><td>".stripslashes($row['article_name'])."</td><td>".$row['user_id']."</td><td>".$row['user']."</td><td>".$row['ip_address']."</td><td>".$row['host_name']."</td><td>".$row['country']."</td><td>"
      .$row['region']."</td><td>".$row['city']."</td><td>".$row['coordinates']."</td><td>".stripslashes($row['ISP_address'])."</td></tr>";

      $id = $row['article_id'];
      $name = $row['article_name'];
      if( array_key_exists($name, $count)){
        $count[$name] = $count[$name] + 1;
      }
      else

      $count[$name] = 1;
    }
    //   print_r($count);
    //
    // echo("<hr> </hr>");
    // $total=0;
    // foreach($count as $key=>$row) {
    //   $total = $total + $row;
    //   if($key!="N/a"){
    //   echo "Article: " .stripslashes($key). "                                           |                                                            \t". "Clicks: ". $row."<br>";
    // }
    //
    // }
    // echo "| TOTAL CLICKS ON WEBSITE |:   " . $total;
    // echo("<hr> </hr>");
    echo '</table>';


  }



  ?>
