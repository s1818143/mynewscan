<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>schema_local (copy)</title>
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Cookie">
  <link rel="stylesheet" href="assets/css/Footer-Basic.css">
  <link rel="stylesheet" href="assets/css/Footer-Dark.css">
  <link rel="stylesheet" href="assets/css/Navigation-with-Button.css">
  <link rel="stylesheet" href="assets/css/Pretty-Footer.css">
  <link rel="stylesheet" href="assets/css/styles.css">
  <link rel="stylesheet" href="assets/css/untitled.css">
</head>

<body>
  <script src="assets/js/jquery.min.js"></script>
  <script src="assets/bootstrap/js/bootstrap.min.js"></script>
  <?php
  require_once('../db_connection.php');
  $id = $_GET['id'];
  session_start();
  $logged=0;
  $caption="Log In";
  $logging_link="login.php";
  $button ="Sign Up";
  $button_link ="register.php";
  $user_status=-1;
  $userID=-1;

 if(isset($_SESSION['logged'])){
    if($_SESSION['logged'])
    $logged=1;
  }

  if($logged==1){
    $userID= $_SESSION['user_id'];
    $login_details = "SELECT * FROM users where user_id={$userID}";
    $login_response= @mysqli_query($connection,$login_details);

    if($login_response){
      $user_record = mysqli_fetch_array($login_response);
      $user_status = $user_record['status'];
      $username = $user_record['username'];

      if($user_status){
        $caption = "Log Out";
        $logging_link ="login.php";
        $button ="{$username}";
        $button_link ="profile.php";
      }

    }


    else{

      echo "no response ".mysqli_errno($connection);
    }


}

if($userID!=-1){
  $article_points = 0;
  $querySelect =  mysqli_query($connection, "SELECT * FROM activity WHERE user_id = {$userID} AND article_id={$id}");
  if(mysqli_num_rows($querySelect) < 1){
    $article_points = 2;
    $updateQuery = mysqli_query($connection,"UPDATE users SET total_points = total_points + 2 WHERE user_id = {$userID}");
  }
}




  $query = "SELECT * FROM articles WHERE id = {$id}";
  $response = @mysqli_query($connection,$query);

  if($response) {

    while ($row = mysqli_fetch_array($response)) {

      ?>


      <div id="nav">
        <nav class="navbar navbar-light navbar-expand-md fixed-top navigation-clean-button has-pattern">
          <div class="container-fluid">
            <div class="logo pull-left">     		
          		<a class="navbar-brand" href="schema_local.php">
                  	<img class="logo" src="assets/img/news.png" id="logo-img">
            		<span>MyNewsScan</span>
          		</a>
        	</div>        

            <button class="navbar-toggler" data-toggle="collapse" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
            <div class="collapse navbar-collapse" id="navcol-1">
              <ul class="nav navbar-nav ml-auto">

                <li class="nav-item dropdown" role="presentation"><a class="nav-link" href="#" id="aboutUs">About Us</a>
                  <div class="dropdown-content">
                    <a href="#">Reward System</a>
                    <a href="#">Contact Us</a>
                    <a href="#">About Us</a>
                  </div></li>
                  <!--<li class="nav-item" role="presentation"><a class="nav-link" href="#" id="contact">Contact</a></li>-->
                </ul><span class="navbar-text actions"> <a href="<?php echo $logging_link;?>" id="login" class="login"><?php echo $caption;?> </a> <a class="btn btn-light action-button" role="button" id="loginButton" href="<?php echo $button_link;?>"><?php echo $button;?>
                </a></span></div>
              </div>
            </nav>
          </div>


          <div>
            <br>

            <div class="justify-content-center" >
              <br><br>
              <h5 class="text-center"><b>Suggested reading time</b>:  <?php echo "{$row['reading_time']}";  ?>  minutes   | <?php echo "{$row['topic']}";   ?> | <?php echo "{$row['category']}";?></h5>

              <p class="text-center" >Article Source: <a href="<?php echo $row['link'];?>"><?php echo $row['link'];?></a></p>
              <br>
              <div class="container-fluid" style="width:90%; align-content: center;">
                <div class="embed-responsive embed-responsive-16by9">
                  <iframe class="embed-responsive-item" src="<?php echo $row['article_path'];?>" allowfullscreen></iframe>
                </div>
              </div>

              <?php
            }
          }
          else
          {
            echo  "Could not issue DB query";
            echo mysqli_errno($connection);

          }
          ?>


          <div id="container" class="container-fluid" style="width:90%; align-content: center;">

            <br>
            <h3>Please answer the following questions:</h3>
            <br>
            <div>
              <p>How much do you like the article?</p>
              <div class="form-check"><input class="form-check-input" name="question1" type="radio" required id="radio-1a"><label id="labelradio-1a"  class="form-check-label" for="formCheck-1a">Not at all.</label></div>
              <div class="form-check"><input class="form-check-input" name="question1" type="radio" required id="radio-1b"><label id="labelradio-1b"  class="form-check-label" for="formCheck-1b">Not very much.</label></div>
              <div class="form-check"><input class="form-check-input" name="question1" type="radio" required id="radio-1c"><label id="labelradio-1c"  class="form-check-label" for="formCheck-1c">Somewhat.</label></div>
              <div class="form-check"><input class="form-check-input" name="question1" type="radio" required id="radio-1d"><label id="labelradio-1d"  class="form-check-label" for="formCheck-1d">Very much.</label></div>
            </div>
            <br>
            <div>
              <p>How useful do you find this article?</p>
              <div class="form-check"><input class="form-check-input" name="question2" type="radio" required id="radio-2a"><label id="labelradio-2a"  class="form-check-label" for="formCheck-2a">Not at all.</label></div>
              <div class="form-check"><input class="form-check-input" name="question2" type="radio" required id="radio-2b"><label id="labelradio-2b"  class="form-check-label" for="formCheck-2b">Not very much.</label></div>
              <div class="form-check"><input class="form-check-input" name="question2" type="radio" required id="radio-2c"><label id="labelradio-2c"  class="form-check-label" for="formCheck-2c">Somewhat.</label></div>
              <div class="form-check"><input class="form-check-input" name="question2" type="radio" required id="radio-2d"><label id="labelradio-2d"  class="form-check-label" for="formCheck-2d">Very much.</label></div>
            </div>

            <br>
            <div>
              <p>How accurate do you think this article is? </p>
              <div class="form-check"><input class="form-check-input" name="question3"  type="radio" required id="radio-3a"><label id="labelradio-3a" class="form-check-label" for="formCheck-1">Fake news.</label></div>
              <div class="form-check"><input class="form-check-input" name="question3" type="radio" required id="radio-3b"><label id="labelradio-3b" class="form-check-label" for="formCheck-1">Significantly inaccurate or misleading.</label></div>
              <div class="form-check"><input class="form-check-input" name="question3" type="radio" required id="radio-3c"><label id="labelradio-3c" class="form-check-label" for="formCheck-1">Mostly accurate.</label></div>
              <div class="form-check"><input class="form-check-input" name="question3" type="radio" required id="radio-3d"><label id="labelradio-3d"  class="form-check-label" for="formCheck-1">Accurate.</label></div>
            </div>
            <br>
            <div>
              <p>How confident do you feel about your accuracy judgment?</p>
              <div class="form-check"><input class="form-check-input" name="question4" type="radio" required id="radio-4a"><label id="labelradio-4a" class="form-check-label" for="formCheck-1">Not confident.</label></div>
              <div class="form-check"><input class="form-check-input" name="question4" type="radio" required id="radio-4b"><label id="labelradio-4b" class="form-check-label" for="formCheck-1">Educated guess.</label></div>
              <div class="form-check"><input class="form-check-input" name="question4" type="radio" required id="radio-4c"><label id="labelradio-4c" class="form-check-label" for="formCheck-1">Fairly confident. </label></div>
              <div class="form-check"><input class="form-check-input" name="question4" type="radio" required id="radio-4d"><label id="labelradio-4d" class="form-check-label" for="formCheck-1">Very confident.</label></div>
            </div>

            <br>
            <div>
              <p>How much did your prior view on this subject change?</p>
              <div class="form-check"><input class="form-check-input" name="question6" type="radio" required id="radio-6a"><label id="labelradio-6a" class="form-check-label" for="formCheck-1">Not at all.</label></div>
              <div class="form-check"><input class="form-check-input" name="question6" type="radio" required id="radio-6b"><label id="labelradio-6b" class="form-check-label" for="formCheck-1">Not very much.</label></div>
              <div class="form-check"><input class="form-check-input" name="question6" type="radio" required id="radio-6c"><label id="labelradio-6c" class="form-check-label" for="formCheck-1">Fairly. </label></div>
              <div class="form-check"><input class="form-check-input" name="question6" type="radio" required id="radio-6d"><label id="labelradio-6d" class="form-check-label" for="formCheck-1">Completely.</label></div>
            </div>
            <br>
            <div>
              <p>How clearly written do you think this article is?</p>
              <div class="form-check"><input class="form-check-input" name="question7" type="radio" required id="radio-7a"><label id="labelradio-7a" class="form-check-label" for="formCheck-1">Not at all.</label></div>
              <div class="form-check"><input class="form-check-input" name="question7" type="radio" required id="radio-7b"><label id="labelradio-7b" class="form-check-label" for="formCheck-1">Not Very Clear.</label></div>
              <div class="form-check"><input class="form-check-input" name="question7" type="radio" required id="radio-7c"><label id="labelradio-7c" class="form-check-label" for="formCheck-1">Fairly clear. </label></div>
              <div class="form-check"><input class="form-check-input" name="question7" type="radio" required id="radio-7d"><label id="labelradio-7d" class="form-check-label" for="formCheck-1">Very clear.</label></div>
            </div>
			<br>
            <div>
              <p>Please provide any additional comments, e.g. to justify your opinion about the article which you feel may not be conventional.</p>
              <input type"text" id="comments" size="100">
            </div>
          </div>

          <div class="container-fluid" style="width:90%; align-content: center;">
            <br>
            <p> <input type ="submit" name="submit" id= "button" class="submit_btn" value="Submit and Proceed to Exploration"/></p>
          </div>



        </div>
        <div class="justify-content-center footer-basic">
          <footer>
            <div class="row">
            <div class="col-sm-6 col-md-4 footer-navigation">
                <br>
                <img src="assets/img/neuro-header.png" id="edinburgh">
                <br><br>
                <img src="assets/img/informatics_logo.gif" id="informatics">
            </div>                
              <div class="col-sm-6 col-md-4 footer-contacts">
                  <div><span class="fa fa-map-marker footer-contacts-icon"> </span>
                    <p id="address"><span class="new-line-span">1 George Square&nbsp;</span> Edinburgh, United Kingdom</p>
                  </div>
                  <div><i class="fa fa-phone footer-contacts-icon"></i>
                    <p id="number" class="footer-center-info email text-left"><br>+447766706580<br><br></p>
                  </div>
                  <div><i class="fa fa-envelope footer-contacts-icon"></i>
                    <p id="email"> <a href="#" target="_blank" style="color:#82649c;"><br>gedi.luksys@ed.ac.uk<br>ahsun.tariq@gmail.com<br></a></p>
                  </div>
                </div>
                <div class="clearfix"></div>
                <div class="col-md-4 footer-about">
                  <h4>About the project</h4>
                  <p><br>MyNewsScan is a meta-news project, currently under development, headed by Dr. Gedi Luksys and Dr. Robin Hill from the University of Edinburgh and run by UoE graduates Ahsun Tariq, Mariana Martinez Juarez, Yiyun Zhu, Zhewen Du, Jiachen Cai. Its main purpose is to provide useful and high quality news selection of various topics to international readers. At the same time we aim to collect readers' feedback about the articles that will facilitate our research on the role of schemas on learning, decision making, and more generally on how factors such as perceived news accuracy, familiarity and usefulness affect their performance and popularity.

MyNewsScan is not a commercial entity. Any questions or enquiries should be addressed to the email addresses on left.&nbsp;<br><br></p>
                    <div class="social-links social-icons"><a href="#"><i class="fa fa-facebook"></i></a><a href="#"><i class="fa fa-twitter"></i></a><a href="#"><i class="fa fa-linkedin"></i></a><a href="#"><i class="fa fa-github"></i></a></div>
                  </div>
                </div>
              </footer>
            </div>

          </body>


          <script>
          var specificList =[];
          var specificAnswers =[];
          var pointsList=[];
          var question ={};
          var questionList =[];

          function pushQuestion(question, questionID){
            return {
              "question" : question,
              "questionID": questionID
            };
          }

          var question = pushQuestion("How much do you like the article?", "1");
          questionList.push(question);
          var question = pushQuestion("How useful do you find this article?", "2");
          questionList.push(question);
          var question = pushQuestion("How accurate do you think this article is?", "3");
          questionList.push(question);
          var question = pushQuestion("How confident do you feel about your accuracy judgment?", "4");
          questionList.push(question);
          var question = pushQuestion("Please provide any additional comments, e.g. to justify your opinion about the article which you feel may not be conventional.", "5");
          questionList.push(question);
          var question = pushQuestion("How much did your prior view on this subject change?", "6");
          questionList.push(question);
          var question = pushQuestion("How clearly written do you think this article is?", "7");
          questionList.push(question);




          console.log(<?php echo $id;?>);
          <?php
          $query2 = "SELECT * FROM questions WHERE article_id = {$id}";
          $response2 = @mysqli_query($connection,$query2);

          if($response2) {
            $i=0;
            while ($question = mysqli_fetch_array($response2)) {

              ?>
              var question = pushQuestion("<?php echo $question['question'];?>", "<?php echo $question['question_id'];?>;");
              questionList.push(question);
              var mainDiv = document.getElementById("container");
              var br = document.createElement("BR");
              mainDiv.appendChild(br);
              var div = document.createElement("div");
              mainDiv.appendChild(div);
              var para = document.createElement("p");
              div.appendChild(para);
              para.innerHTML = "<?php echo $question['question'];?>";
              var correct_answer = <?php echo $question['correct_choice'];?>;
              var points = <?php echo $question['points'];?>;
              var div1 = document.createElement("div");
              div.appendChild(div1);
              div1.classList.add('form-check');
              var input1 = document.createElement("INPUT");
              input1.setAttribute("type","radio");
              input1.classList.add('form-check-input');
              input1.setAttribute("name","Specificquestion"+<?php echo $i;?>);
              input1.setAttribute("id","radio-a"+<?php echo $i;?>);
              input1.checked=1;
              div1.appendChild(input1);
              var label1 = document.createElement("LABEL");
              label1.classList.add('form-check-label');
              label1.setAttribute("for","radio-a"+<?php echo $i;?>);
              label1.setAttribute("id","labelradio-a"+<?php echo $i;?>);
              label1.innerHTML="<?php echo $question['choice1'];?>";
              label1.value=1;
              div1.appendChild(label1);
              specificList.push(input1);

              var div2 = document.createElement("div");
              div.appendChild(div2)
              div2.classList.add('form-check');
              var input2 = document.createElement("INPUT");
              input2.setAttribute("type","radio");
              input2.classList.add('form-check-input');
              input2.setAttribute("name","Specificquestion"+<?php echo $i;?>);
              input2.setAttribute("id","radio-b"+<?php echo $i;?>);
              div2.appendChild(input2);
              var label2 = document.createElement("LABEL");
              label2.classList.add('form-check-label');
              label2.setAttribute("for","radio-b"+<?php echo $i;?>);
              label2.setAttribute("id","labelradio-b"+<?php echo $i;?>);
              label2.innerHTML="<?php echo $question['choice2'];?>";
              label2.value=2;
              div2.appendChild(label2);
              specificList.push(input2);

              var div3 = document.createElement("div");
              div.appendChild(div3)
              div3.classList.add('form-check');
              var input3 = document.createElement("INPUT");
              input3.setAttribute("type","radio");
              input3.classList.add('form-check-input');
              input3.setAttribute("name","Specificquestion"+<?php echo $i;?>);
              input3.setAttribute("id","radio-c"+<?php echo $i;?>);
              div3.appendChild(input3);
              var label3 = document.createElement("LABEL");
              label3.classList.add('form-check-label');
              label3.setAttribute("for","radio-c"+<?php echo $i;?>);
              label3.setAttribute("id","labelradio-c"+<?php echo $i;?>);
              label3.innerHTML="<?php echo $question['choice3'];?>";
              label3.value=3;
              div3.appendChild(label3);
              specificList.push(input3);

              var div4 = document.createElement("div");
              div.appendChild(div4)
              div4.classList.add('form-check');
              var input4 = document.createElement("INPUT");
              input4.setAttribute("type","radio");
              input4.classList.add('form-check-input');
              input4.setAttribute("name","Specificquestion"+<?php echo $i;?>);
              input4.setAttribute("id","radio-d"+<?php echo $i;?>);
              div4.appendChild(input4);
              var label4 = document.createElement("LABEL");
              label4.classList.add('form-check-label');
              label4.setAttribute("for","radio-d"+<?php echo $i;?>);
              label4.setAttribute("id","labelradio-d"+<?php echo $i;?>);
              label4.innerHTML="<?php echo $question['choice4'];?>";
              label4.value=4;
              div4.appendChild(label4);
              specificList.push(input4);
              specificAnswers.push(correct_answer);
              pointsList.push(points);
              <?php
              $i++;}
              $index = $i;
            }
            else{
              echo  "Could not issue DB query";
              echo mysqli_errno($connection);
            }
            ?>
          </script>

          <script>
          //LOGOUT SCRIPT

          var userID = <?php echo $userID;?>;
          var logged = <?php echo $logged; ?>;
          var status = <?php echo $user_status;?>;
          var form = $('#login')[0]
          var formData3 = new FormData(form);
          formData3.append("status",status);
          formData3.append("userID",userID);
          // var logbutton = document.getElementById("login");

          if(logged==1){
          $( "#login" ).click(function( event ) {
             event.preventDefault();

              $.ajax({ url: 'logout.php',


                        type: 'post',
                        data: formData3,
                        contentType: false, // NEEDED, DON'T OMIT THIS (requires jQuery 1.6+)
                        processData: false,

                   success: function(output) {
                                alert(output);
                                window.location.replace("<?php echo $logging_link;?>");

                            },
                    error: function(request, error){
                      alert("Error: Could not issue ajax request\n"+"Status: "+status+"\nuserID:"+userID+error+request);
                    }
              });



            });
          }
      </script>


    <script>

    <?php

try{

    $ip = $_SERVER['REMOTE_ADDR'];

    function curl($url){
      $ch = curl_init();
      curl_setopt($ch, CURLOPT_URL,$url);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
      $return = curl_exec($ch);
      curl_close ($ch);
      return $return;

    }


    $string = curl("http://ipinfo.io/{$ip}/json");
    $details=json_decode($string);
    $loc = $details->loc;
    $myString= (string)$loc;
    $myArray = explode(',', $myString);

    $lat=$myArray[0];
    $long = $myArray[1];
    $url = "https://maps.googleapis.com/maps/api/geocode/json?latlng=$lat,$long&sensor=false&key=AIzaSyDQmKWbeMPdUDQk83emuOfACLIdmvgF7Cc";

    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_HEADER, false);
    curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_ENCODING, "");
    $curlData = curl_exec($curl);
    curl_close($curl);

    $address = json_decode($curlData);
    $street= $address->results[0]->formatted_address;




;
    $user = 'unregistered user';
    $user_id ='-1';
    if($logged){
      $user_id = $userID ;
      $user_query = "SELECT * FROM users WHERE user_id = {$user_id}";
      $response = @mysqli_query($connection,$user_query);
      if($response){
        $user_record = mysqli_fetch_array($response);
        $user = $user_record['username'];
      }
    }



    $ip_address = $details->ip;
    $host_name = $details->hostname;
    $country = $details->country;
    $region = $details->region;
    $city = $details->city;
    $coodrinates = $details->loc;
    $ISP_address = $street ;

    if(empty($ip_address))
    $ip_address = 'unreachable';
    if(empty($host_name))
    $host_name = 'unreachable';
    if(empty($country))
    $country = 'unreachable';
    if(empty($region ))
    $region = 'unreachable';
    if(empty($city))
    $city = 'unreachable';
    if(empty($coodrinates))
    $coodrinates = 'unreachable';
    if(empty($ISP_address ))
    $ISP_address = 'unreachable';


  }


  catch (Exception $e) {
    ?>

    console.log(<?php echo 'Caught exception: ',  $e->getMessage(), "\n";?>);
    <?php
    $ip_address = 'unreachable';
    $host_name = 'unreachable';
    $country = 'unreachable';
    $region = 'unreachable';
    $city = 'unreachable';
    $coodrinates = 'unreachable';
    $ISP_address = 'unreachable';
}

$article_id = $id ;
$article_name;
$question_id  ;
$question ;
$answer_choice;
$answer_label;

$article_query = "SELECT * FROM articles WHERE id = {$article_id}";
$response = @mysqli_query($connection,$article_query);
if($response){
  $article_record = mysqli_fetch_array($response);
  $article_name = $article_record['name'];
}

    ?>


    // console.log(<?php echo $string;?>);
    // console.log("<?php echo $street;?>");


    </script>


    
    <script>
    $( "#button" ).click(function( event ) {
      var logged = <?php echo $logged; ?>;
      var userpoints=0;
      var comments = document.getElementById("comments").value;

      var answerList= [];
      var q1a = document.getElementById("radio-1a").checked;
      document.getElementById("labelradio-1a").value=1;
      var q1b = document.getElementById("radio-1b").checked;
      document.getElementById("labelradio-1b").value=2;
      var q1c = document.getElementById("radio-1c").checked;
      document.getElementById("labelradio-1c").value=3;
      var q1d = document.getElementById("radio-1d").checked;
      document.getElementById("labelradio-1d").value=4;

      var q2a = document.getElementById("radio-2a").checked;
      document.getElementById("labelradio-2a").value=1;
      var q2b = document.getElementById("radio-2b").checked;
      document.getElementById("labelradio-2b").value=2;
      var q2c = document.getElementById("radio-2c").checked;
      document.getElementById("labelradio-2c").value=3;
      var q2d = document.getElementById("radio-2d").checked;
      document.getElementById("labelradio-2d").value=4;

      var q3a = document.getElementById("radio-3a").checked;
      document.getElementById("labelradio-3a").value=1;
      var q3b = document.getElementById("radio-3b").checked;
      document.getElementById("labelradio-3b").value=2;
      var q3c = document.getElementById("radio-3c").checked;
      document.getElementById("labelradio-3c").value=3;
      var q3d = document.getElementById("radio-3d").checked;
      document.getElementById("labelradio-3d").value=4;

      var q4a = document.getElementById("radio-4a").checked;
      document.getElementById("labelradio-4a").value=1;
      var q4b = document.getElementById("radio-4b").checked;
      document.getElementById("labelradio-4b").value=2;
      var q4c = document.getElementById("radio-4c").checked;
      document.getElementById("labelradio-4c").value=3;
      var q4d = document.getElementById("radio-4d").checked;
      document.getElementById("labelradio-4d").value=4;

      var q6a = document.getElementById("radio-6a").checked;
      document.getElementById("labelradio-6a").value=1;
      var q6b = document.getElementById("radio-6b").checked;
      document.getElementById("labelradio-6b").value=2;
      var q6c = document.getElementById("radio-6c").checked;
      document.getElementById("labelradio-6c").value=3;
      var q6d = document.getElementById("radio-6d").checked;
      document.getElementById("labelradio-6d").value=4;
      
      var q7a = document.getElementById("radio-7a").checked;
      document.getElementById("labelradio-7a").value=1;
      var q7b = document.getElementById("radio-7b").checked;
      document.getElementById("labelradio-7b").value=2;
      var q7c = document.getElementById("radio-7c").checked;
      document.getElementById("labelradio-7c").value=3;
      var q7d = document.getElementById("radio-7d").checked;
      document.getElementById("labelradio-7d").value=4;

      //+!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
      // 0 stands for answeared , 1 stands for unanswered
      var flag =0;
      if(q1a || q1b || q1c || q1d){
        // userpoints++;
        if(q1a)
        answerList.push("labelradio-1a");
        if(q1b)
        answerList.push("labelradio-1b");
        if(q1c)
        answerList.push("labelradio-1c");
        if(q1d)
        answerList.push("labelradio-1d");
      }
      else{
        flag=1;
        answerList.push("unanswered");
      }
      

      if(q2a || q2b || q2c || q2d){
        // userpoints++;
        if(q2a)
        answerList.push("labelradio-2a");
        if(q2b)
        answerList.push("labelradio-2b");
        if(q2c)
        answerList.push("labelradio-2c");
        if(q2d)
        answerList.push("labelradio-2d");
      }
      else{
        flag=1;
        answerList.push("unanswered");
      }

      if(q3a || q3b || q3c || q3d){
        // userpoints++;
        if(q3a)
        answerList.push("labelradio-3a");
        if(q3b)
        answerList.push("labelradio-3b");
        if(q3c)
        answerList.push("labelradio-3c");
        if(q3d)
        answerList.push("labelradio-3d");
      }
      else{
        flag=1;
        answerList.push("unanswered");
      }

      if(q4a || q4b || q4c || q4d){
        // userpoints++;
        if(q4a)
        answerList.push("labelradio-4a");
        if(q4b)
        answerList.push("labelradio-4b");
        if(q4c)
        answerList.push("labelradio-4c");
        if(q4d)
        answerList.push("labelradio-4d");
      }
      else{
        flag=1;
        answerList.push("unanswered");
      }


        if(comments===""){
          document.getElementById("comments").value="no comments";
        }
        answerList.push("comments");
  

        if(q6a || q6b || q6c || q6d){
          // userpoints++
          if(q6a)
          answerList.push("labelradio-6a");
          if(q6b)
          answerList.push("labelradio-6b");
          if(q6c)
          answerList.push("labelradio-6c");
          if(q6d)
          answerList.push("labelradio-6d");
        }
        else{
          flag=1;
          answerList.push("unanswered");
        }

        if(q7a || q7b || q7c || q7d){
          // userpoints++
          if(q7a)
          answerList.push("labelradio-7a");
          if(q7b)
          answerList.push("labelradio-7b");
          if(q7c)
          answerList.push("labelradio-7c");
          if(q7d)
          answerList.push("labelradio-7d");
        }
        else{
          flag=1;
          answerList.push("unanswered");
        }


      // console.log(document.getElementById("radio-1a").checked);
      // console.log(document.getElementById("radio-1b").checked);
      // console.log(document.getElementById("radio-1c").checked);
      // console.log(document.getElementById("radio-1d").checked);
      // if(flag==0){
      console.log(questionList);
      console.log(answerList.length);
      var i =0;
      var check = 1;
      var message="";
      var general_question_count = 0;
      answerList.forEach(function(element) {
        console.log("-------------------------------------------------------------------");
        console.log("question is: " + questionList[i].question);
        console.log("questionID is: " + questionList[i].questionID);
        console.log(element);
        console.log(typeof element);
        // console.log(document.getElementById(element).textContent);
        // console.log(document.getElementById(element).value);


        var Question = questionList[i].question;
        var question_id = questionList[i].questionID;
        var answer_choice = (element != "unanswered" && question_id != "5") ? document.getElementById(element).value : 5;
        var answer_label = (element != "unanswered" && question_id != "5") ? document.getElementById(element).textContent : "unanswered";
        var article_id ="<?php echo $article_id ;?>";
        var article_name ="<?php echo $article_name ;?>";
        var user = "<?php echo $user ;?>";
        var user_id = "<?php echo $user_id  ;?>";
        var ip_address = "<?php echo $ip_address;?>";
        var host_name = "<?php echo $host_name;?>";
        var country = "<?php echo $country;?>";
        var region = "<?php echo $region;?>";
        var city = "<?php echo $city;?>";
        var coordinates = "<?php echo $coodrinates;?>";
        var isp_address = "<?php echo $ISP_address;?>";


        if(question_id == 5)
        {
          console.log("question is: "+ Question);

          document.getElementById(element).textContent=document.getElementById(element).value;

          answer_label =document.getElementById(element).textContent;

          console.log("answer label is: "+answer_label);

          console.log("answer choice is: "+answer_choice);

          //when checking comments, if user comment then add 1
          if(document.getElementById(element).value !="no comments") {
            general_question_count ++;
          }

        }

        //points calculation except question 5
        if( element != "unanswered" && question_id != 5 ){
          general_question_count ++;
        }

        var question_form = $('#container')[0]
        var formdata = new FormData(question_form);

        formdata.append("article_id", article_id);
        formdata.append("article_name",article_name);
        formdata.append("user",user);
        formdata.append("user_id",user_id);
        formdata.append("ip_address",ip_address);
        formdata.append("hostname",host_name);
        formdata.append("country",country);
        formdata.append("region",region);
        formdata.append("city",city);
        formdata.append("coordinates",coordinates);
        formdata.append("isp_address",isp_address);

        formdata.append("question", Question);
        formdata.append("question_id", question_id);
        formdata.append("answer_choice",answer_choice);
        formdata.append("answer_label",answer_label);

      

        $.ajax({ url: 'add_answers.php',


            type: 'post',
            data: formdata,
            contentType: false, // NEEDED, DON'T OMIT THIS (requires jQuery 1.6+)
            processData: false,
            success: function(output) {
              // alert(output);
              check = check*1;
              message = output+message;
            
            
            },
            error: function(request, status, error){
              check = check*0;
            }
        });

        i++;
      });

      console.log("-------------------------------------------------------------------");




      var j=0;

      //these two are related to specific questions
      var numberOfQuestions = 0;
      var correctCount = 0;


      specificList.forEach(function(item) {


        if(item.checked)


        {
          numberOfQuestions++;

          console.log("-------------------------------------------------------------------");
          console.log("i = "+i);
          if(i<questionList.length){
            console.log("question is: " + questionList[i].question);
            var Question = questionList[i].question;
            console.log("questionID is: " + questionList[i].questionID);
            var question_id = questionList[i].questionID;

            i++;
          }



          var id = item.getAttribute("id");
          var labelID = "label"+id;
          console.log("choice is: " + document.getElementById(labelID).value);
          console.log("answer label is: " + document.getElementById(labelID).textContent);

          // var userpoints=0;
          if(document.getElementById(labelID).value == specificAnswers[j])
          {
            console.log("Correct choice for question: "+ Question );
            console.log("Points awarded: "+ pointsList[j]);
            // userpoints = pointsList[j];
            correctCount++;

          }
          else
            console.log("Incorrect choice")
          j++;
          console.log("correct count: " +correctCount);

          var answer_choice = document.getElementById(labelID).value;
          var answer_label = document.getElementById(labelID).textContent;
          var article_id ="<?php echo $article_id ;?>";
          var article_name ="<?php echo $article_name ;?>";
          var user = "<?php echo $user ;?>";
          var user_id = "<?php echo $user_id  ;?>";
          var ip_address = "<?php echo $ip_address;?>";
          var host_name = "<?php echo $host_name;?>";
          var country = "<?php echo $country;?>";
          var region = "<?php echo $region;?>";
          var city = "<?php echo $city;?>";
          var coordinates = "<?php echo $coodrinates;?>";
          var isp_address = "<?php echo $ISP_address;?>";



          var question_form = $('#container')[0]
          var formdata = new FormData(question_form);


          formdata.append("article_id", article_id);
          formdata.append("article_name",article_name);
          formdata.append("user",user);
          formdata.append("user_id",user_id);
          formdata.append("ip_address",ip_address);
          formdata.append("hostname",host_name);
          formdata.append("country",country);
          formdata.append("region",region);
          formdata.append("city",city);
          formdata.append("coordinates",coordinates);
          formdata.append("isp_address",isp_address);

          formdata.append("question", Question);
          formdata.append("question_id", question_id);
          formdata.append("answer_choice",answer_choice);
          formdata.append("answer_label",answer_label);

          // formdata.append("points",userpoints);

          if(question_id=="5"){
            console.log("Question is :" +Question);
            console.log("answer choice is: " +answer_choice);
            console.log("answer lable is: " +answer_label);
          }
          $.ajax({ url: 'add_answers.php',


          type: 'post',
          data: formdata,
          contentType: false, // NEEDED, DON'T OMIT THIS (requires jQuery 1.6+)
          processData: false,
          success: function(output) {
            check = check*1;
            message = output+message;

            // alert(output);
          },
          error: function(request, status, error){
            check = check*0;

          }
        });

          // i++;
        }

        });


      //var score = numberOfQuestions ; //this is the number of specific questions( we should use o as initial score)
      var score = 0; //起始分数是general question
      if(check==0)
       alert("There was an error submitting the answers.");
      else {
        //POINTS CALCULATION
      if(specificList.length<=0 || correctCount == 0){
        score = general_question_count; //if no specific questions or correctly answer 0 specific questions, 
                                        //final score equals to the number of answered question 
      }else{
          if(general_question_count == 0){
            score = correctCount; //no general question, we only multiply 1
          }else{
            score = correctCount * general_question_count;
          }
      }


        userpoints= userpoints + score;
        console.log(userpoints+"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"+general_question_count);
        console.log(score+"???????????????????????????????????????????????????????????"+correctCount);
        if(logged)
          alert("Thank you for your response.\nYou anwered  " + general_question_count +" general question(s).\nYou anwered "+ correctCount+" correct out of "+ numberOfQuestions+" specific question(s).\n");
        else
          alert("Thank you for your response."+"\n");
        // location.reload();
      }

      if(logged){
      console.log("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
      var user_id = "<?php echo $user_id  ;?>";
      var article_id = "<?php echo $article_id  ;?>";
      var question_form = $('#container')[0]
      var formdata2 = new FormData(question_form);
      formdata2.append("user_id", user_id );
      formdata2.append("article_id", article_id );
      formdata2.append("points",userpoints);
      console.log(formdata2);
      $.ajax({ url: 'add_points.php',


      type: 'post',
      data: formdata2,
      contentType: false, // NEEDED, DON'T OMIT THIS (requires jQuery 1.6+)
      processData: false,
      success: function(output) {
        // alert(output);

      },
      error: function(request, status, error){
        alert("error adding points")

      }
    });
}




      console.log("done");
      specificList=[];

      console.log("<?php echo $article_id ;?>");
      console.log("<?php echo $user ;?>");
      console.log("<?php echo $user_id ;?>");
      console.log("<?php echo $ip_address;?>");
      console.log("<?php echo $host_name;?>");
      console.log("<?php echo $country;?>");
      console.log("<?php echo $region;?>");
      console.log("<?php echo $city;?>");
      console.log("<?php echo $coodrinates;?>");
      console.log("<?php echo $ISP_address;?>");

    window.location.replace("schema_local.php");



    });

  </script>

  <script>
  function insertActivity(ArticleID,ArticleName){

    var logged = <?php echo $logged; ?>;
    var user = "<?php echo $user ;?>";
    var user_id = "<?php echo $user_id  ;?>";
    var ip_address = "<?php echo $ip_address;?>";
    var host_name = "<?php echo $host_name;?>";
    var country = "<?php echo $country;?>";
    var region = "<?php echo $region;?>";
    var city = "<?php echo $city;?>";
    var coordinates = "<?php echo $coodrinates;?>";
    var isp_address = "<?php echo $ISP_address;?>";

    var activity = user + " opened article: " + ArticleName;

      var activity_form = $('#gridRow')[0]
      var formdata = new FormData(activity_form);


      formdata.append("article_id", ArticleID);
      formdata.append("article_name",ArticleName);
      formdata.append("user",user);
      formdata.append("activity",activity);
      formdata.append("user_id",user_id);
      formdata.append("ip_address",ip_address);
      formdata.append("hostname",host_name);
      formdata.append("country",country);
      formdata.append("region",region);
      formdata.append("city",city);
      formdata.append("coordinates",coordinates);
      formdata.append("isp_address",isp_address);

      $.ajax({ url: 'add_activity.php',


      type: 'post',
      data: formdata,
      contentType: false, // NEEDED, DON'T OMIT THIS (requires jQuery 1.6+)
      processData: false,
      success: function(output) {
        console.log(output);



      },
      error: function(request, status, error){
        alert("could not issue ajax request for activity.")

      }
    });

}

insertActivity(<?php echo $id;?>, "<?php echo $article_name; ?>" );



</script>
<script>

function displayPoints(){

  <?php   if($logged==1){
    $userID= $_SESSION['user_id'];
    $login_details = "SELECT * FROM users where user_id={$userID}";
    $login_response= @mysqli_query($connection,$login_details);

    if($login_response){
      $user_record = mysqli_fetch_array($login_response);
      $points =$username." | Points:". $user_record['total_points'];
    }
  }
  else $points="Register to get points!";

  ?>
 return "<?php echo $points;?>";

}
var points = document.getElementById("loginButton");
points.innerHTML=displayPoints();

if(logged)
points.setAttribute("href","mypoints.php");
else {
 points.setAttribute("href","register.php");
}

</script>
    </html>