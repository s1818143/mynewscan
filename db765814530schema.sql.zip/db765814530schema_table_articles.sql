
-- --------------------------------------------------------

--
-- 表的结构 `articles`
--

CREATE TABLE `articles` (
  `id` int(11) NOT NULL,
  `name` varchar(300) NOT NULL,
  `time_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `topic` varchar(30) NOT NULL,
  `category` varchar(30) NOT NULL,
  `length` varchar(30) NOT NULL,
  `tags` varchar(1000) DEFAULT NULL,
  `overview` varchar(1000) DEFAULT NULL,
  `link` varchar(1000) NOT NULL,
  `image_path` varchar(300) DEFAULT NULL,
  `reading_time` int(3) NOT NULL,
  `article_path` varchar(300) NOT NULL,
  `likes` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- 转存表中的数据 `articles`
--

INSERT INTO `articles` (`id`, `name`, `time_added`, `topic`, `category`, `length`, `tags`, `overview`, `link`, `image_path`, `reading_time`, `article_path`, `likes`) VALUES
(4, 'The Future of Learning and How It Could Change Your Classroom', '2018-06-25 23:03:18', 'Education', 'Interview', 'Medium', 'E-learning, distance learning, future, education', 'This article presents some suggestions for professors and teaching institutions to make learning more effective. It discusses some methods such as rewarding teachers for bringing innovative ideas etc.', 'https://www.chronicle.com/article/The-Future-of-LearningHow/243437', 'Images/5b3174b668cb8Robot-clip-art-book-covers-feJCV3-clipart.png', 10, 'articles/article5b3174b5b0ca7.html', NULL),
(5, 'A hard lesson: The digital classroom can really fail', '2018-06-25 23:04:30', 'Education', 'Analysis', 'Medium', 'E-learning, distance learning, future, education', 'This article gives the disadvantages of a flipped class room environment. It discusses some controversial issues that may arise when children explore content under free exploration in a digital environment. It also claims that a digital learning environment needs more staff for monitoring content.', 'https://www.theglobeandmail.com/opinion/article-a-hard-lesson-the-digital-classroom-can-really-fail/', 'Images/5b3174fe4a9c5digital-learning-background-with-tablet-and-educational-items_23-2147598080.jpg', 10, 'articles/article5b3174fe1d57c.html', NULL),
(6, 'Stress and serious anxiety: how the new GCSE is affecting mental health', '2018-06-25 23:10:17', 'Education', 'Analysis', 'Long', 'Learning, school, gcse', 'This article claims that the new system for General Certificate for Secondary Education is responsible for the deterioration of mental health among high school students with many factors such as stress, anxiety and depression. Moreover, schools have to address the challenges of offering better mental support.', 'https://www.theguardian.com/education/2018/may/17/stress-and-serious-anxiety-how-the-new-gcse-is-affecting-mental-health', 'Images/5b317659a385f4256.jpg', 15, 'articles/article5b3176591e7f8.html', NULL),
(7, 'Don\\\'t just blame teachers when system is at fault, says UNESCO', '2018-06-25 23:12:48', 'Education', 'Analysis', 'Short', 'Learning, school, world', 'This article presents a report by United Nations educational agency, according to which educational problems are not solely due to teachers. It suggests alternatives to meet these challenges on a larger scale such as scrutinizing school performance through external organizations, accountability of governments etc.', 'https://news.un.org/en/story/2017/10/569142-dont-just-blame-teachers-when-system-fault-says-unesco', 'Images/5b3176f030ccbimage1170x530cropped.jpg', 5, 'articles/article5b3176ef782b2.html', NULL),
(16, 'How to approach a career changeâ€¦ and secure your next job', '2018-07-25 19:30:14', 'Education', 'Advice', 'Medium', 'Jobs, career', NULL, 'https://jobs.theguardian.com/article/how-to-approach-a-career-change-and-secure-your-next-job/?INTCMP=gdnwb_copts_merchlow_jobs_LRRON_component_article_career_change', NULL, 8, 'articles/article5b58cfc63ab34.html', NULL),
(19, 'The great learning curve: how to improve your study habits', '2018-07-27 13:44:27', 'Education', 'Advice', 'Short', 'Exams', NULL, 'https://www.theguardian.com/education/2018/mar/22/the-great-learning-curve-how-to-improve-your-study-habits', NULL, 5, 'articles/article5b5b21bb83d0f.html', NULL),
(20, 'Why eight hours a night isnâ€™t enough, according to a leading sleep scientist', '2018-07-27 13:51:38', 'Health_nutrition', 'Interview', 'Long', '', NULL, 'https://qz.com/1301123/why-eight-hours-a-night-isnt-enough-according-to-a-leading-sleep-scientist/?utm_source=pocket&amp;utm_medium=email&amp;utm_campaign=pockethits', NULL, 30, 'articles/article5b5b2369a1306.html', NULL),
(25, 'Tesla driver says car was in autopilot when it crashed at 60mph', '2018-07-31 11:24:14', 'Technology', 'News', 'Short', '', '', 'https://www.theguardian.com/technology/2018/may/14/tesla-crash-utah-driver-autopilot-mode-elon-musk', NULL, 4, 'articles/article5b6046de6405f.html', NULL),
(27, 'Brain Activity Alternates While Walking', '2018-08-02 15:34:36', 'Technology', 'News', 'Short', '', NULL, 'https://www.insidescience.org/news/brain-activity-alternates-while-walking', NULL, 6, 'articles/article5b63248b80de2.html', NULL),
(47, 'Bobby Seagull: How to make teenagers love maths', '2018-08-05 21:12:33', 'Education', 'Analysis', 'Medium', '', '', 'https://www.ft.com/content/83e9ea1c-f246-11e7-bb7d-c3edfe974e9f', NULL, 9, 'articles/article5b6768413fcf6.html', NULL),
(48, 'Should you raise your kids religious? Hereâ€™s what the science says', '2018-08-07 22:44:14', 'Education', 'Analysis', 'Long', 'Education, religion, children', NULL, 'https://qz.com/1301084/should-you-raise-your-kids-religious-heres-what-the-science-says/', NULL, 15, 'articles/article5b6a20bd7b3a2.html', NULL),
(52, 'How the Enlightenment Ends', '2018-08-08 18:50:49', 'Technology', 'Analysis', 'Long', '', NULL, 'https://www.theatlantic.com/magazine/archive/2018/06/henry-kissinger-ai-could-mean-the-end-of-human-history/559124/', NULL, 22, 'articles/article5b6b3b88856cd.html', NULL),
(56, 'World Health Organization Says Trans Fats Should Be Eliminated From By 2023', '2018-08-09 12:16:20', 'Health_nutrition', 'Analysis', 'Medium', '', NULL, 'https://sciencetrends.com/world-health-organization-says-trans-fats-should-be-eliminated-from-by-2023/', NULL, 8, 'articles/article5b6c309291fcf.html', NULL),
(57, 'Trump Wants More Asylums and Some Psychiatrists Agree', '2018-08-09 12:20:29', 'Health_nutrition', 'Discussion', 'Medium', '', NULL, 'https://www.nytimes.com/2018/03/05/health/mental-illness-asylums.html', NULL, 12, 'articles/article5b6c318c5820c.html', NULL),
(59, 'The internet has become information chaos', '2018-08-10 16:53:36', 'Technology', 'Analysis', 'Short', '', NULL, 'https://thenextweb.com/contributors/2018/07/17/the-internet-has-become-information-chaos/', NULL, 5, 'articles/article5b6dc30f371c6.html', NULL),
(68, 'Harper\\\'s Index - June', '2019-06-14 15:01:14', 'Education', 'Analysis', 'Short', '', NULL, 'https://harpers.org/archive/2019/06/harpers-index-june-2019', NULL, 4, 'articles/article5d03b6b9855df.html', NULL),
(69, 'From what to eat before a date... to the best diet if your family is prone to cancer', '2019-06-14 15:04:46', 'Health_nutrition', 'Advice', 'Short', '', NULL, 'https://www.nationalgeographic.co.uk/science-and-technology/2019/02/what-eat-date-best-diet-if-your-family-prone-cancer', NULL, 5, 'articles/article5d03b78d04e29.html', NULL),
(70, 'Scientists explain how happiness makes us less creative', '2019-06-17 19:28:42', 'Technology', 'Discussion', 'Short', '', NULL, 'https://qz.com/790226/happiness-creativity-neuroscience/', NULL, 4, 'articles/article5d07e9eac278c.html', NULL),
(71, 'Record ethnic minority students at Oxford', '2019-06-17 19:33:22', 'Education', 'News', 'Short', '', NULL, 'https://www.bbc.co.uk/news/education-48541423', NULL, 4, 'articles/article5d07eb01781d3.html', NULL),
(75, 'Finland is winning the war on fake news. What itâ€™s learned may be crucial to Western democracy', '2019-06-17 19:58:05', 'Education', 'Analysis', 'Long', '', NULL, 'https://edition.cnn.com/interactive/2019/05/europe/finland-fake-news-intl/', NULL, 20, 'articles/article5d07f0cda160c.html', NULL),
(76, 'Child held near cliff edge at Seven Sisters prompts warning', '2019-06-17 20:01:59', 'Health_nutrition', 'News', 'Short', '', NULL, 'https://www.bbc.co.uk/news/uk-england-sussex-48026250', NULL, 4, 'articles/article5d07f1b6baa6b.html', NULL),
(77, 'This AI is so good at writing that its creators won\\\'t let you use it', '2019-06-17 20:07:25', 'Technology', 'Analysis', 'Medium', '', NULL, 'https://us.cnn.com/2019/02/18/tech/dangerous-ai-text-generator/index.html', NULL, 8, 'articles/article5d07f2fbf1c95.html', NULL),
(79, 'â€˜For 30 years Iâ€™ve been obsessed by why children get leukaemia. Now we have an answerâ€™', '2019-06-17 21:09:48', 'Health_nutrition', 'Interview', 'Medium', '', NULL, 'https://www.theguardian.com/science/2018/dec/30/children-leukaemia-mel-greaves-microbes-protection-against-disease', NULL, 7, 'articles/article5d08019c20a1b.html', NULL),
(81, 'What Really Happened to Malaysiaâ€™s Missing Airplane', '2019-06-17 22:20:55', 'Technology', 'Analysis', 'Long', '', NULL, 'https://www.theatlantic.com/magazine/archive/2019/07/mh370-malaysia-airlines/590653/', NULL, 37, 'articles/article5d08124705575.html', NULL),
(82, 'Itâ€™s a Winner-Take-All World, Whether You Like It or Not', '2019-06-17 22:26:10', 'Education', 'Advice', 'Long', '', NULL, 'https://www.theatlantic.com/ideas/archive/2019/06/its-a-winner-take-all-world-heres-how-to-get-ahead/591700/', NULL, 16, 'articles/article5d08138226752.html', NULL),
(83, 'The Death of an Adjunct', '2019-06-17 22:31:34', 'Education', 'Analysis', 'Long', '', NULL, 'https://www.theatlantic.com/education/archive/2019/04/adjunct-professors-higher-education-thea-hunter/586168/', NULL, 20, 'articles/article5d0814c59b50b.html', NULL),
(84, 'The Worst Patients in the World', '2019-06-17 22:34:06', 'Health_nutrition', 'Analysis', 'Long', '', NULL, 'https://www.theatlantic.com/magazine/archive/2019/07/american-health-care-spending/590623/', NULL, 16, 'articles/article5d08155e4657d.html', NULL),
(85, 'Merkel advises graduates: Break the walls that hem you in', '2019-06-17 22:39:46', 'Education', 'Advice', 'Medium', '', NULL, 'https://news.harvard.edu/gazette/story/2019/05/at-harvard-commencement-merkel-tells-grads-break-the-walls-that-hem-you-in/', NULL, 11, 'articles/article5d0816b1bff0f.html', NULL);
