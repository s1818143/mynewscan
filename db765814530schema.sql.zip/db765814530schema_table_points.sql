
-- --------------------------------------------------------

--
-- 表的结构 `points`
--

CREATE TABLE `points` (
  `point_id` int(11) NOT NULL,
  `article_id` int(11) NOT NULL,
  `article_name` varchar(300) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `user` varchar(30) DEFAULT NULL,
  `points` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
