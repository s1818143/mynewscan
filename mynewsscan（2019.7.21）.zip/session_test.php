<!DOCTYPE html>
<?php session_start(); ?>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <div class="">
      <span>
        <?php echo $_SESSION['user_id'];?>
      </span>
      <span>
        <?php echo $_SESSION['success']; ?>
      </span>
      <span>
        <?php echo "test success";?>
      </span>
    </div>
  </body>
</html>
