<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>ModifyArticle</title>
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
  <div class="topnav">
      <a class="active" href="add_article.html">Add Articles</a>
      <a class="active" href="question_form.php">Add Questions</a>
      <a href="modifyArticle.php">Modify Articles & Questions</a>
      <a href="exploration.php">View Exploration</a>
      <a href="answers.php">View Answers</a>
      <a href="statistics.php">Statistics</a>

  </div>
  <h1>Statistics</h1>
  <form action="" method="post">


    <!-- <p> order by <select onchange="=sort(this.id)" name="select" id ="order">
    <option value = "answer_id">Answer ID</option>
    <option value = "time_added">Time Added</option>
    <option value = "article_id">Article ID</option>
    <option value = "question_id">Question ID</option>
    <option value = "user_id">User ID</option>
    <option value = "ip_address">IP Address</option>
    <option value = "country">Country</option>
  </select></p>
  <input name="Display" type="submit" value ="Click to display results"></input> -->
</form>







<?php




require_once('../db_connection.php');
// $orderby = $_POST['select'];
$query = "SELECT * FROM recentAnswers";
$query2 = "SELECT * FROM activity";
// echo "Query: ". $query;
$response = @mysqli_query($connection,$query);
$response2 = @mysqli_query($connection,$query2);

$articles =array();
$count =array();


while ($row = mysqli_fetch_assoc($response2)){


  $id = $row['article_id'];
  $name = $row['article_name'];
  if( array_key_exists($name, $count)){
    $count[$name] = $count[$name] + 1;
  }
  else
  $count[$name] = 1;

}


while ($row = mysqli_fetch_assoc($response)){

  $id = $row['article_id'];
  $name = $row['article_name'];


  $question = $row['question'];
  $answer = $row['answer_choice'];



  if(isset($articles[$name][$question][$answer]))
  $articles[$name][$question][$answer] = $articles[$name][$question][$answer] + 1;



  else{

    $articles[$name][$question][$answer] = 1;
  }

}

echo("<hr> </hr>");
$total=0;
foreach($count as $key=>$row) {
  $total = $total + $row;
  if($key!="N/a"){
    echo "Article: " .stripslashes($key). "                                           |                                                            \t". "Clicks: ". $row."<br>";
  }

}
echo "| TOTAL CLICKS ON WEBSITE |:   " . $total;
echo("<hr> </hr>");
?><h1>Article Specific Stats</h1> <?php
echo "<br> <hr></hr>";
foreach($articles as $key1 => $value1){
  echo $key1;
  echo "<br>";
  foreach($value1 as $key2 => $value2){
    echo "<br>";
    echo $key2;
    echo "<br>";
    foreach($value2 as $key3 => $value3){
      echo "For choice: ". $key3;
      echo "       Number of responses: ";
      echo($value3);
      echo "<br>";
    }
  }

  echo "<br>";
  echo "<br>";
  echo"<hr></hr>";

}
// print_r($articles);
// echo '</table>';









?>














</body>
</html>
