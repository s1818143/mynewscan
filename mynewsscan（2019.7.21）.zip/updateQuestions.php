<!DOCTYPE html>
<?php

//include('updateAll.php');

require_once('../db_connection.php');

$article_id = isset($_GET['article_id']) ? $_GET['article_id'] : '';

$queryArticle = "SELECT * FROM articles where id=".$article_id;
$response = @mysqli_query($connection,$queryArticle);
$row = mysqli_fetch_assoc($response);

$queryQuestion = "SELECT * FROM questions where article_id=".$article_id;
$responseq = @mysqli_query($connection,$queryQuestion);


?>

<html lang="en">
  <head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Update Article</title>
	<!-- favicon -->

	<!-- link to google font -->
	<link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">



  </head>
  <body>
   &nbsp  <a  href=modifyArticle.php>Back</a>
    <br>
    <h1> Update Questions</h1>

    <h2> Article: <?php echo $row["name"] ?> </h2>
    <p>
    <a  href=<?php echo $row["link"] ?>><?php echo $row["link"] ?></a>

    <form action="" method="post" id="form" enctype="multipart/form-data">
    <p>Select a question: <select name="question" >

      <?php while ($questions = mysqli_fetch_assoc($responseq)) {
   		echo "<option>" . $questions['question'] . "</option>";
	    } ?>
      </select></p>
    <p> <input type ="submit" name="delete"  class="submit_btn" value="Delete Question" onclick="deleteQuestion()"  />

  &nbsp &nbsp  <input type ="submit" name="modify"  class="submit_btn" value="Modify Question" onclick="modifyQuestion()"/>
</form>
<?php
  if(isset($_POST['delete']))
  {
    $question_name= mysqli_real_escape_string($connection,$_POST['question']);
    $article_id = isset($_GET['article_id']) ? $_GET['article_id'] : '';
    $query = "DELETE FROM questions WHERE question='$question_name' and article_id=$article_id";

    if (mysqli_query($connection, $query)) {
      echo "Record deleted successfully";
    } else {
      echo "Error updating record: " . mysqli_error($connection);

    }

  }

  if(isset($_POST['modify']))
  {
    $question_name= mysqli_real_escape_string($connection,$_POST['question']);
    $article_id = isset($_GET['article_id']) ? $_GET['article_id'] : '';
    $query = "SELECT * FROM questions WHERE question='$question_name' and article_id=$article_id";
    $response=mysqli_query($connection, $query);
    $row= mysqli_fetch_assoc($response);

    if ($row>0) {

      $q= $row["question"];
      $points= $row["points"];
      $c1=$row["choice1"];
      $c2=$row["choice2"];
      $c3=$row["choice3"];
      $c4=$row["choice4"];
      $cc=$row["correct_choice"];

      echo "  <form  method='post' id='form'>";
      echo "  <p> Question: <input type='text' required name='question2'  value='$q'  />";
      echo "  <p> Question Point: <input type='text' required name='points' value='$points' />";
      echo "  <p> Answer choice 1: <input type='text' required name='choice1' value='$c1' />";
      echo "  <p> Answer choice 2: <input type='text' required name='choice2' value='$c2' />";
      echo "  <p> Answer choice 3: <input type='text' required name='choice3' value='$c3' />";
      echo "  <p> Answer choice 4: <input type='text' required name='choice4' value='$c4' />";
      echo "  <p> Correct Choice: <input type='text' required name='cc' value='$cc' />";

      echo "  <p> <input type='submit' name='updateq' class='submit_btn' value='Update' >";
      echo "</form>";



    } else {
      echo "Error updating record: " . mysqli_error($connection);

    }




  }

  if(isset($_POST['updateq'])){

    $article_id = isset($_GET['article_id']) ? $_GET['article_id'] : '';


    $question2 = mysqli_real_escape_string($connection,$_POST['question2']);
    $points = mysqli_real_escape_string($connection,$_POST['points']);
    $choice1 = mysqli_real_escape_string($connection,$_POST['choice1']);
    $choice2 = mysqli_real_escape_string($connection,$_POST['choice2']);
    $choice3 = mysqli_real_escape_string($connection,$_POST['choice3']);
    $choice4 = mysqli_real_escape_string($connection,$_POST['choice4']);
    $correct_choice = mysqli_real_escape_string($connection,$_POST['cc']);


    $sqlquery = "UPDATE questions SET question='$question2', points='$points', choice1='$choice1', choice2='$choice2', choice3='$choice3', choice4='$choice4', correct_choice='$correct_choice' WHERE question='$question2' and article_id=$article_id";


    if (mysqli_query($connection, $sqlquery)) {
      echo '<script language="javascript">';
      echo 'alert("Question updated")';
      echo '</script>';
    } else {

      echo '<script language="javascript">';
      $message="Error updating record: " . mysqli_error($connection);
      echo 'alert("' . $message . '")';
      echo '</script>';

  }


  }

  ?>
</body>

</html>
