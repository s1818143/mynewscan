<html>
<?php
session_start();
require_once('../db_connection.php');

$query = "SELECT * FROM answers ORDER BY time_added";
$response= @mysqli_query($connection,$query);


$logged=0;
$caption="Log In";
$logging_link="login.php";
$button ="Sign Up";
$button_link ="register.php";
$user_status=-1;
$userID=-1;

if(isset($_SESSION['logged'])){
  if($_SESSION['logged'])
    $logged=1;
}

if($logged==1){
$userID= $_SESSION['user_id'];
$login_details = "SELECT * FROM users where user_id={$userID}";
$login_response= @mysqli_query($connection,$login_details);

if($login_response){
 $user_record = mysqli_fetch_array($login_response);
 $user_status = $user_record['status'];
 $username = $user_record['username'];
 $email = $user_record['email'];
 $total_pints = $user_record['total_points'];
 if($user_status){
   $caption = "Log Out";
   $logging_link ="login.php";
   $button ="{$username}";
   $button_link ="profile.php";
 }

}


else{

echo "no response ".mysqli_errno($connection);
}

}
?>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MyNewsScan</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css">
		<link rel="stylesheet" href="assets/fonts/material-icons.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Cookie">
    <link rel="stylesheet" href="assets/css/Footer-Basic.css">
    <link rel="stylesheet" href="assets/css/Footer-Dark.css">
    <link rel="stylesheet" href="assets/css/Navigation-with-Button.css">
    <link rel="stylesheet" href="assets/css/Pretty-Footer.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/untitled.css">
    <link rel="stylesheet" href="assets/css/profile.css">
</head>

<body>

<div id="nav" style="font-size:1rem;">
	<nav class="navbar navbar-light navbar-expand-md fixed-top navigation-clean-button has-pattern">
		<div class="container-fluid">
            <div class="logo pull-left">     
              <a class="navbar-brand" href="schema.php">
                <img class="logo" src="assets/img/news.png" id="logo-img">
                <span>MyNewsScan</span>
              </a>
            </div>
			<button class="navbar-toggler" data-toggle="collapse" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
				<div class="collapse navbar-collapse" id="navcol-1">
						<ul class="nav navbar-nav ml-auto">
							<li class="nav-item dropdown" role="presentation"><a class="nav-link" href="#" id="aboutUs">About Us</a>
								<div class="dropdown-content">
									<a href="#">Reward System</a>
									<a href="#">Contact Us</a>
									<a href="#">About Us</a>
								</div></li>
								<!--<li class="nav-item" role="presentation"><a class="nav-link" href="#" id="contact">Contact</a></li>-->
						</ul><span class="navbar-text actions"> <a href="<?php echo $logging_link;?>" id="login" class="login"><?php echo $caption;?> </a> <a class="btn btn-light action-button" id="loginButton" role="button" href="<?php echo $button_link;?>"><?php echo $button;?>
						</a></span></div>
</div>
	</nav>
</div>

<div class="g-bd2 g-bd2-1">
	<div class="g-mn">
		<div class="g-mnc">
			<div class="accountsetting">
				<div class="u-ttl">
					<h3>My Points</h3>
				</div>
				<div class="container">
					<div class="u-colslist">
						<ul class="j-container">
							<span class="detailtitle">Total Points Earned:</span><span><?php echo $total_pints ; ?></span>
						</ul>
						<ul class="j-container">
							<span class="detailtitle">Answers</span>
						</ul>
						<!-- <span class="detailtitle">Points Details</span>
						<form action="" method="post">
							<input name="Display" type="submit" value ="Click to show details"></input>
						</form> -->

						<!-- <div id="pointstable" class="table-responsive">
							<table class="table table-hover">
								<thead>
									<tr>
										<th class="divcssth-1">Time</th>
										<th class="divcssth-2">Activity</th>
										<th class="divcssth-3">Points</th>
										<th class="divcssth-4">Notes</th>
									</tr>
								</thead>

								<tbody>
									<tr>
										<td>2018/08/04</td>
										<td>Browsing a new article</td>
										<td>2</td>
										<td></td>
									</tr>
								</tbody>
								</table>
								</div> -->
								<div>
								<?php

									require_once('../db_connection.php');
									$query = "SELECT * FROM answers WHERE user_id = {$userID} ORDER BY time_added desc";
									$response = @mysqli_query($connection,$query);


									echo '<div id="pointstable" class="table-responsive"><table class="table table-hover">';
									echo '<thead><tr><th class="divcssth-1">Time</th><th class="divcssth-2">Article Name</th><th class="divcssth-3">Question</th><th class="divcssth-4">Answers</th></tr></thead>';

									while ($row = mysqli_fetch_assoc($response)){
											echo "<tbody><tr><td>".$row['time_added']."</td><td><a href="."'ArticlePage.php?id={$row['article_id']}'>".stripslashes($row['article_name'])."</a></td><td>".$row['question']."</td><td>".$row['answer_label']."</td></tr></tbody>";
									}
									echo '</table></div>';


								?>
						</div>

					</div>
				</div>
			</div>
		</div>
	</div>

	<div class="g-sd">
		<div class="nav-left">
			<h2>My Account</h2>
			<ul id="mod_sel">
				<li><a href="profile.php" hidefocus="hidefocus">Account Setting</a></li>
				<li class="crt"><a href="mypoints.php" hidefocus="hidefocus">My Points</a></li>
				<li><a href="recentreading.php" hidefocus="hidefocus">Recent Reading</a></li>
			</ul>
		</div>
	</div>
</div>




<div class="footer-basic">
	<footer>
		<div class="row">
            <div class="col-sm-6 col-md-4 footer-navigation">
                <br>
                <img src="assets/img/neuro-header.png" id="edinburgh">
                <br><br>
                <img src="assets/img/informatics_logo.gif" id="informatics">
            </div>				
            <div class="col-sm-6 col-md-4 footer-contacts">
					<div><span class="fa fa-map-marker footer-contacts-icon"> </span>
						<p id="address"><span class="new-line-span">1 George Square&nbsp;</span> Edinburgh, United Kingdom</p>
					</div>
					<div><i class="fa fa-phone footer-contacts-icon"></i>
						<p id="number" class="footer-center-info email text-left"><br>0131 650 3522 (Mon/Thurs)<br><br></p>
					</div>
					<div><i class="fa fa-envelope footer-contacts-icon"></i>
						<p id="email"> <a href="#" target="_blank" style="color:#82649c;"><br>edinburgh.neuroscience@ed.ac.uk<br><br></a></p>
					</div>
				</div>
				<div class="clearfix"></div>
				<div class="col-md-4 footer-about">
					<h4>About the company</h4>
					<p><br>Edinburgh Neuroscience is a vibrant, interdisciplinary, cross-College community at the University of Edinburgh whose ethos is collaborative and collegiate cooperation across all research areas. With over 500 fundamental and clinical
						researchers, based in 185 laboratories, our work spans the life course from prenatal to old age and attempts to answer the fundamental questionshow does the brain develop and function across the lifespanhow can it be protected
						and repaired?Our research takes place within a range of centres that work closely together, with clinical work being integrated across all areas. Edinburgh Neuroscience is widely recognised for its extensive integration of outstanding
						clinical, biomedical, informatics and psychology research.&nbsp;<br><br></p>
						<div class="social-links social-icons">
                          <a href="#"><i class="fa fa-facebook" style="padding-top: 8px;"></i></a>
                          <a href="#"><i class="fa fa-twitter" style="padding-top: 8px;"></i></a>
                          <a href="#"><i class="fa fa-linkedin" style="padding-top: 8px;"></i></a>
                          <a href="#"><i class="fa fa-github" style="padding-top: 8px;"></i></a>
                        </div>
					</div>
				</div>
			</footer>
</div>

<script src="assets/js/jquery.min.js"></script>
<script src="assets/bootstrap/js/bootstrap.min.js"></script>
<script>	//LOGOUT SCRIPT

var userID = <?php echo $userID;?>;
var logged = <?php echo $logged; ?>;
var status = <?php echo $user_status;?>;
var form = $('#login')[0]
var formData3 = new FormData(form);
formData3.append("status",status);
formData3.append("userID",userID);
// var logbutton = document.getElementById("login");

if(logged==1){
$( "#login" ).click(function( event ) {
   event.preventDefault();

    $.ajax({ url: 'logout.php',


              type: 'post',
              data: formData3,
              contentType: false, // NEEDED, DON'T OMIT THIS (requires jQuery 1.6+)
              processData: false,

         success: function(output) {
                      alert(output);
                      window.location.replace("<?php echo $logging_link;?>");

                  },
          error: function(request, error){
            alert("Error: Could not issue ajax request\n"+"Status: "+status+"\nuserID:"+userID+error+request);
          }
    });



  });
}
    </script>

    <script>

    function displayPoints(){

      <?php   if($logged==1){
        $userID= $_SESSION['user_id'];
        $login_details = "SELECT * FROM users where user_id={$userID}";
        $login_response= @mysqli_query($connection,$login_details);

        if($login_response){
          $user_record = mysqli_fetch_array($login_response);
          $points =$username." | Points:". $user_record['total_points'];
        }
      }
      else $points="Register to get points!";

      ?>
     return "<?php echo $points;?>";

    }
    var points = document.getElementById("loginButton");
    points.innerHTML=displayPoints();

    if(logged)
    points.setAttribute("href","mypoints.php");
    else {
     points.setAttribute("href","register.php");
    }

    </script>
</body>
</html>
