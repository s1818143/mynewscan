<?php
require_once('../db_connection.php');


$missing_data = array();


if(empty($_POST['article_id'])){
    $missing_data[] = 'article_id';
}
else{
    $article_id = trim($_POST['article_id']);
    $article_id = htmlspecialchars(addslashes($article_id));
}

if(empty($_POST['article_name'])){
     $missing_data[] = 'article_name';
}
else {
    $article_name = htmlspecialchars(addslashes(ucfirst($_POST['article_name'])));
 }

if(empty($_POST['user'])){
    $missing_data[] = 'user';
}
else{
    $user = trim($_POST['user']);
    $user = htmlspecialchars(addslashes($user));
}

if(empty($_POST['user_id'])){
    $missing_data[] = 'user_id';
}
else{
    $user_id = trim($_POST['user_id']);
    $user_id = htmlspecialchars(addslashes($user_id));
}

if(empty($_POST['ip_address'])){
    $missing_data[] = 'ip_address';
}
else{
    $ip_address= trim($_POST['ip_address']);
    $ip_address= htmlspecialchars(addslashes($ip_address));
}

if(empty($_POST['hostname'])){
    $missing_data[] = 'hostname';
}
else{
    $hostname= trim($_POST['hostname']);
    $hostname = htmlspecialchars(addslashes($hostname));
}

if(empty($_POST['country'])){
    $missing_data[] = 'country';
}
else{
    $country= trim($_POST['country']);
    $country = htmlspecialchars(addslashes($country));
}

if(empty($_POST['region'])){
    $missing_data[] = 'region';
}
else{
    $region= trim($_POST['region']);
    $region = htmlspecialchars(addslashes($region));
}

if(empty($_POST['city'])){
    $missing_data[] = 'city';
}
else{
    $city= trim($_POST['city']);
    $city = htmlspecialchars(addslashes($city));
}


if(empty($_POST['coordinates'])){
    $missing_data[] = 'coordinates';
}
else{
    $coordinates= trim($_POST['coordinates']);
    $coordinates = htmlspecialchars(addslashes($coordinates));
}


if(empty($_POST['isp_address'])){
    $missing_data[] = 'isp_address';
}
else{
    $isp_address= trim($_POST['isp_address']);
    $isp_address = htmlspecialchars(addslashes($isp_address));
}


if(empty($_POST['question'])){
    $missing_data[] = 'question';
}
else{
    $question= trim($_POST['question']);
    $question = htmlspecialchars(addslashes($question));
}

if(empty($_POST['question_id'])){
    $missing_data[] = 'question_id';
}
else{
    $question_id= trim($_POST['question_id']);
    $question_id = htmlspecialchars(addslashes($question_id));
}

if(empty($_POST['answer_choice'])){
    $answer_choice[] = 'answer_choice';
}
else{
    $answer_choice= trim($_POST['answer_choice']);
    $answer_choice = htmlspecialchars(addslashes($answer_choice));
}


if(empty($_POST['answer_label'])){
    $missing_data[] = 'answer_label';
}
else{
    $answer_label= trim($_POST['answer_label']);
    $answer_label = htmlspecialchars(addslashes($answer_label));
}

// if(!empty($_POST['points'])){
//
//     $points= $_POST['points'];
//     $points = htmlspecialchars(addslashes($points));
// }


    if(empty($missing_data)){
        // print_r($steps);


        $query1 = "INSERT INTO answers (time_added, article_id, article_name, question_id, question, answer_choice, answer_label, user_id, user, ip_address, host_name, country, region, city, coordinates, ISP_address)
                            VALUES (NOW(),?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

        $statement1 = mysqli_prepare($connection,$query1);
        mysqli_stmt_bind_param($statement1,"isisisissssssss", $article_id,$article_name,
            $question_id,$question,$answer_choice,$answer_label, $user_id,$user,$ip_address,$hostname,$country,$region,$city,$coordinates,$isp_address);

        mysqli_stmt_execute($statement1);
        $rows_changed1 = mysqli_stmt_affected_rows($statement1);

        $id = mysqli_insert_id($connection);

        $Insertid=0;
      		?>
<script>
   console.log("+++++++++++++++++++++++++++if out side +++++++++++++++++++++++++++++++++++");
</script>
<?php
        if($user_id!=-1){
		?>
<script>
   console.log("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
</script>
<?php
          $querySelect =  mysqli_query($connection, "SELECT * FROM recentanswers WHERE user_id = {$user_id} AND article_id={$article_id} AND question_id={$question_id}");
          echo mysqli_num_rows($querySelect);
          if(mysqli_num_rows($querySelect) > 0){

            $updateQuery = mysqli_query($connection,"UPDATE recentanswers SET time_added=NOW(), article_id=$article_id , article_name='$article_name', question_id=$question_id, question='$question', answer_choice=$answer_choice, answer_label='$answer_label', user_id=$user_id, user='$user', ip_address='$ip_address', host_name='$hostname', country='$country', region='$region',
            city='$city', coordinates='$coordinates',ISP_address='$isp_address' WHERE user_id = {$user_id} AND article_id={$article_id} AND question_id={$question_id}");
            $rows_updated = mysqli_affected_rows($connection);
            if($rows_updated>0)
            echo"done";
            else {
              echo"no row found";
            }

          }

          else{
            $query1 = "INSERT INTO recentanswers (time_added, article_id, article_name, question_id, question, answer_choice, answer_label, user_id, user, ip_address, host_name, country, region, city, coordinates, ISP_address)
            VALUES (NOW(),?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

            $statement2 = mysqli_prepare($connection,$query1);
            mysqli_stmt_bind_param($statement2,"isisisissssssss", $article_id,$article_name,
            $question_id,$question,$answer_choice,$answer_label, $user_id,$user,$ip_address,$hostname,$country,$region,$city,$coordinates,$isp_address);

            mysqli_stmt_execute($statement2);
            $rows_updated = mysqli_stmt_affected_rows($statement2);

            $Insertid = mysqli_insert_id($connection);
          }
        }

        // if($user_id!=-1){
        // $query = "SELECT * FROM users WHERE user_id = {$user_id} ";
        // $response= @mysqli_query($connection,$query);
        //
        // if($response){
        //   $row = mysqli_fetch_array($response);
        //   $existingPoints = $row['total_points'];
        //   $newpoints = $existingPoints + $points;
        //
        //
        //   $pointsQuery = "UPDATE users SET total_points = {$newpoints} WHERE user_id = {$user_id}";
        //   mysqli_query($connection, $pointsQuery);
        //
        // }
        // }
        if(($rows_changed1>0)&&($rows_updated>0)){

            echo "\nanswers added succesfully\n";


            mysqli_stmt_close($statement1);
            // mysqli_stmt_close($statement2);
            mysqli_close($connection);


        }

        else{

            echo "\nThere was an error adding the answer. Please recheck the form and try again.\n";
            echo mysqli_error($connection);
            // echo "\nrows1: ". $rows_changed1;
            // echo "\nrows2: ". $rows_changed2;
            // if(($rows_changed1>0)&&($rows_changed2<1)){
            //   $query_delete = "DELETE FROM recipe WHERE id = {$id}";
            //   $response= @mysqli_query($connection,$query_delete);
            // }

            mysqli_stmt_close($statement1);
            // mysqli_stmt_close($statement2);
            mysqli_close($connection);
        }


    }

    else{

        echo "\nError. Please make sure that you have entered the following field(s) and resubmit the form:";
        // print_r($missing_data);

        foreach ($missing_data as $key => $value) {
          echo "\n{$value} (required)";

        }
    }


?>
