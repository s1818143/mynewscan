<?php
require_once('../db_connection.php');
session_start();
setcookie (session_id(), "", time() - 3600);
session_destroy();
session_write_close();
$userID = $_POST['userID'];
$statusQuery= "UPDATE users SET status = 0 WHERE user_id = $userID" ;
$statusResponse = mysqli_query($connection, $statusQuery);
$rows=mysqli_affected_rows($connection);
if($statusResponse){
  if($rows>0)
    echo "You have been succesfully logged out.";
  else
    echo "No rows changed".mysqli_affected_rows($connection);
  }

else {
  echo "no response";
}
 ?>
