<?php 
require_once('../db_connection.php');
?>

<!DOCTYPE html>

<html>

<head>
    <title>About Us</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/Navigation-with-Button.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" type="text/css" href="assets/css/login.css">


</head>

<body>
		<div id="nav">
	    <nav class="navbar navbar-light navbar-expand-md fixed-top navigation-clean-button has-pattern">
	      <div class="container-fluid">
        	<div class="logo pull-left">
          		<a class="navbar-brand" href="schema.php">
            		<img class="logo" src="assets/img/news.png" id="logo-img">
            		<span>MyNewsScan</span>
          		</a>
        	</div>
		  </div>
	    </nav>
	  </div>
<br>

<br>


    <div class="wrap_aboutus">
        <section id="rewardSystem" class="anchor">
            <h1>Reward System</h1>
            <p>
                something need to be filled later something need to be filled later something need to be filled later
                something need to be filled later something need to be filled later something need to be filled later
                something need to be filled later something need to be filled later something need to be filled later
                something need to be filled later something need to be filled later something need to be filled later
                something need to be filled later something need to be filled later something need to be filled later
                something need to be filled later something need to be filled later something need to be filled later
                something need to be filled later something need to be filled later something need to be filled later
            </p>
        </section>
        <hr>
        <section id="contactUs" class="anchor">
            <h1>Contact Us</h1>
            <p>
                something need to be filled later something need to be filled later something need to be filled later
                something need to be filled later something need to be filled later something need to be filled later
                something need to be filled later something need to be filled later something need to be filled later
                something need to be filled later something need to be filled later something need to be filled later
                something need to be filled later something need to be filled later something need to be filled later
                something need to be filled later something need to be filled later something need to be filled later
                something need to be filled later something need to be filled later something need to be filled later
            </p>
        </section>
        <hr>
        <section id="anotherAboutUs" class="anchor">
            <h1>About Us</h1>
            <p>
                something need to be filled later something need to be filled later something need to be filled later
                something need to be filled later something need to be filled later something need to be filled later
                something need to be filled later something need to be filled later something need to be filled later
                something need to be filled later something need to be filled later something need to be filled later
                something need to be filled later something need to be filled later something need to be filled later
                something need to be filled later something need to be filled later something need to be filled later
                something need to be filled later something need to be filled later something need to be filled later
            </p>
        </section>
    </div>


</body>

</html>