<?php
require_once('../db_connection.php');
$query = "SELECT * FROM articles";
$response = @mysqli_query($connection,$query);





        ?>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ModifyArticle</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<div class="topnav">
      <a class="active" href="add_article.html">Add Articles</a>
      <a class="active" href="question_form.php">Add Questions</a>
      <a href="modifyArticle.php">Modify Articles & Questions</a>
      <a href="exploration.php">View Exploration</a>
      <a href="answers.php">View Answers</a>
      <a href="statistics.php">Statistics</a>

</div>
<body>
    <div class="container" id="con">
        <h1>Question Form</h1>
        <h4>Please use this form to add specific questions for an article.</h4>
        <div>
            <p>Select an article: <select name="articles" id="article" onchange="getSource(this.id)"></select></p>
            <p> <a href="" id="source"> </a></p>


            <p>Select number of questions to add for this article: <select name="questions" id="question" onchange="makeQuestions(this.id)" ></select></p>

            <!-- <div>
                <p>Question 1:</p><label>Question: &nbsp; &nbsp;</label><input type="text">
                <p></p><label>Answer choice 1:&nbsp;</label><input type="text">
                <p></p><label>Answer choice 2:&nbsp;</label><input type="text">
                <p></p><label>Answer choice 3:&nbsp;</label><input type="text">
                <p></p><label>Answer choice 4:&nbsp;</label><input type="text"></div>
        </div> -->
    </div>
  </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <div class="container">
    <p> <input type ="submit" name="submit" id= "button" class="submit_btn" value="Submit"/></p>
  </div>
</body>
<script>
<?php
if($response) { ?>
  var ids= {};
  var links = {};
  var question ={};
  var questionList = [];
  var article_id;
function getArticles(id){

  var articles = document.getElementById("article");
  <?php

   $i=0;
  while($row = mysqli_fetch_array($response)){ ?>
  var option = document.createElement("OPTION");
  field = document.createTextNode("<?php echo stripslashes($row['name']);?>");
  option.appendChild(field);
  articles.insertBefore(option,articles.lastChild);
  links["<?php echo stripslashes($row['name']);?>"] = "<?php echo $row['link'];?>";
  ids["<?php echo stripslashes($row['name']);?>"] = "<?php echo $row['id'];?>";
  <?php } ?>

}


  function getSource(id){

    var source = document.getElementById("source");
    var key = document.getElementById("article").value;
    console.log(key);
    console.log(links[key]);
    source.setAttribute("href", links[key] );
    source.innerHTML= links[key];
    article_id = ids[key];



  }
  getArticles("article");
  getSource("article");
  <?php

}

else{
  echo  "Could not issue DB query";
  echo mysqli_errno($connection);
}

?>

function setQuestions(id){
  var select = document.getElementById("question");
    for(var i=1; i<6;i++){
      var option = document.createElement("OPTION");
      field = document.createTextNode(i);
      option.appendChild(field);
      select.insertBefore(option,select.lastChild);
    }
}

setQuestions("question");



function makeQuestions(id){
  var number = document.getElementById("question").value;
  console.log(number);
  if(document.getElementById("mydiv")){
    console.log("exists");
    var x= document.getElementById("mydiv");
    x.remove();
    // links = {};
    question ={};
    questionList = [];
  }
  var div = document.createElement("div");
  div.setAttribute("id","mydiv");

  for(var i=0; i<number; i++){
    var br1 = document.createElement("BR");
    div.appendChild(br1);
    var container= document.getElementById("con");
    container.appendChild(div);
    var p1 = document.createElement("p");
    var index=i+1;
    p1.innerHTML="Question " + index;
    div.appendChild(p1);



    var label0 = document.createElement("LABEL");
    label0.innerHTML="Question:&nbsp";
    div.appendChild(label0);
    var text0 = document.createElement("input");
    text0.setAttribute("type","text");
    text0.setAttribute("id","question"+i);
    div.appendChild(text0);
    var br2 = document.createElement("BR");
    div.appendChild(br2);

    var points = document.createElement("LABEL");
    points.innerHTML="Question Points:&nbsp";
    div.appendChild(points);
    var text_points = document.createElement("input");
    text_points.setAttribute("type","text");
    text_points.setAttribute("id","points"+i)
    div.appendChild(text_points);
    var br2 = document.createElement("BR");
    div.appendChild(br2);

    var label1 = document.createElement("LABEL");
    label1.innerHTML="Answer choice 1:&nbsp";
    div.appendChild(label1);
    var text1 = document.createElement("input");
    text1.setAttribute("type","text");
    text1.setAttribute("id","choice1"+i);
    div.appendChild(text1);
    var br3 = document.createElement("BR");
    div.appendChild(br3);

    var label2 = document.createElement("LABEL");
    label2.innerHTML="Answer choice 2:&nbsp";
    div.appendChild(label2);
    var text2 = document.createElement("input");
    text2.setAttribute("type","text");
    text2.setAttribute("id","choice2"+i);
    div.appendChild(text2);
    var br4 = document.createElement("BR");
    div.appendChild(br4);

    var label3 = document.createElement("LABEL");
    label3.innerHTML="Answer choice 3:&nbsp";
    div.appendChild(label3);
    var text3 = document.createElement("input");
    text3.setAttribute("type","text");
    text3.setAttribute("id","choice3"+i);
    div.appendChild(text3);
    var br5 = document.createElement("BR");
    div.appendChild(br5);

    var label4 = document.createElement("LABEL");
    label4.innerHTML="Answer choice 4:&nbsp";
    div.appendChild(label4);
    var text4 = document.createElement("input");
    text4.setAttribute("type","text");
    text4.setAttribute("id","choice4"+i);
    div.appendChild(text4);
    var br6 = document.createElement("BR");
    div.appendChild(br6);

    var label5 = document.createElement("LABEL");
    label5.innerHTML="Correct choice: &nbsp";
    div.appendChild(label5);
    var text5 = document.createElement("input");
    text5.setAttribute("type","text");
    text5.setAttribute("id","correct_choice"+i);
    div.appendChild(text5);
    var br7 = document.createElement("BR");
    div.appendChild(br7);

    question["indexID"]=i;
    // console.log("id is: " + question["indexID"]);
    questionList.push(question["indexID"]);

  }

}
makeQuestions("question");
  $( "#button" ).click(function( event ) {

    var form = $('#con')[0];
    var formData = new FormData(form);
    var newList ={};

    questionList.forEach(function(index) {
      console.log(index);
      newList["question"]=document.getElementById("question"+index).value;
      newList["question_points"]=document.getElementById("points"+index).value;
      newList["choice1"]=document.getElementById("choice1"+index).value;
      newList["choice2"]=document.getElementById("choice2"+index).value;
      newList["choice3"]=document.getElementById("choice3"+index).value;
      newList["choice4"]=document.getElementById("choice4"+index).value;
      newList["correct_choice"]=document.getElementById("correct_choice"+index).value;
      console.log(newList);

      console.log("article id is: "+article_id);
    for(var item in newList)
    {
      console.log(item +" : " + newList[item]);

      formData.append("id",article_id);
      formData.append(item,newList[item]);


    }
    var x=index+1;
    $.ajax({ url: 'questionScript.php',


              type: 'post',
              data: formData,
              contentType: false, // NEEDED, DON'T OMIT THIS (requires jQuery 1.6+)
              processData: false,
         success: function(output) {
                      alert("Question "+ x + " "+ output);

                  },
          error: function(request, status, error){
            alert("Error: Could not issue ajax request");
          }
    });


      });






  });

</script>
</html>
