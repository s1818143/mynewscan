<?php
session_start();
require_once('../db_connection.php');

//variables
  $username="";
  $email="";
  $errors=array();

//Database connection
  // $connection = mysqli_connect('localhost','root','Mariana4890$','schema');

//USER REGISTRATION
  //When button register is clicked
  if(isset($_POST['register']))
  { //Save values in variables
      //$username = mysql_real_escape_string($_POST['username']);
      //$email = mysql_real_escape_string($_POST['email']);
      //$password1 = mysql_real_escape_string($_POST['password1']);
      //$password2 = mysql_real_escape_string($_POST['password2']);

      $username = mysqli_real_escape_string($connection,$_POST['username']);
      $email = mysqli_real_escape_string($connection,$_POST['email']);
      $password1 = mysqli_real_escape_string($connection,$_POST['password1']);
      $password2 = mysqli_real_escape_string($connection,$_POST['password2']);

      //Validation of the fields
      if(empty($username))
      {
        array_push($errors, "Please insert username");
      }

      if(empty($email))
      {
        array_push($errors, "Please insert email");
      }

      if(empty($password1))
      {
        array_push($errors, "Please insert password");
      }

      if(empty($password2))
      {
        array_push($errors, "Please confirm password");
      }

      if($password1!= $password2)
      {
        array_push($errors, "Passwords do not match");
      }

      //If fields validation is successful, insert user in database
      if(count($errors)==0)
      {
        //validation of username existence
        $sqlquery = "SELECT * FROM users WHERE username='$username'";
  	    $uservalidation = mysqli_query($connection, $sqlquery);
  	     if (mysqli_num_rows( $uservalidation) > 0)
         {
            array_push($errors, "User already exists");
          }
        //If user does not exist, register in the db
        else
        {

        $hashpassword= md5($password1);
        $sqlquery = "INSERT INTO users (username, password, email, status,total_points,profile_pic_path) VALUES('$username', '$hashpassword', '$email', 0,0,'defaltPath')";
        mysqli_query($connection, $sqlquery);

        $_SESSION['username'] = $username;
  	    $_SESSION['success'] = "You are now logged in";
        header('location: login.php');
        }
      }
  }


  //USER Login
    //When button log in is clicked
    if(isset($_POST['login']))
    { //Save values in variables
        //$username = mysql_real_escape_string($_POST['username']);
        //$password2 = mysql_real_escape_string($_POST['password2']);

        $username = mysqli_real_escape_string($connection,$_POST['username']);
        $password = mysqli_real_escape_string($connection,$_POST['password']);

        //Validation of the fields
        if(empty($username))
        {
          array_push($errors, "Please insert username");
        }

        if(empty($password))
        {
          array_push($errors, "Please insert password");
        }


        if (count($errors) == 0) {
         	$password = md5($password);
         	$sqlquery = "SELECT * FROM users WHERE username='$username' AND password='$password'";
         	$answer = mysqli_query($connection, $sqlquery);
          $row = mysqli_fetch_array($answer);
          $userID = $row['user_id'];
         	if (mysqli_num_rows($answer) == 1) {
            $sqlquery= "UPDATE users SET status = 1 WHERE username = '$username'" ;
            $answer = mysqli_query($connection, $sqlquery);
         	$_SESSION['username'] = $username;
         	$_SESSION['success'] = "You are now logged in";
            $_SESSION['user_id'] = $userID;
            $_SESSION['logged'] = true;
            header('location: http://mynewsscan.net/schema.php');
              //exit;

         	}else {
         		array_push($errors, "Username/password are incorrect");
         	}
         }
       }


 ?>
